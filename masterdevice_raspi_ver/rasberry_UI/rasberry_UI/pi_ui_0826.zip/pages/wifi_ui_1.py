# pages/wifi_ui_1.py
import dash
from dash import html, dcc, Input, Output, State, callback, no_update
import dash_bootstrap_components as dbc
import time
import json

# gRPC 클라이언트 및 데이터 매니저 import (강제 경로 설정)
try:
    import sys
    import os
    
    # 현재 파일 기준으로 절대 경로 설정
    current_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(current_dir)  # pages의 상위 디렉토리
    stubs_path = os.path.join(project_root, 'GRPC', 'stubs')
    
    print(f"[WIFI_UI DEBUG] 프로젝트 루트: {project_root}")
    print(f"[WIFI_UI DEBUG] GRPC stubs 경로: {stubs_path}")
    
    if stubs_path not in sys.path:
        sys.path.insert(0, stubs_path)
    
    # client 모듈 import
    import client
    
    # grpc_data_manager는 프로젝트 루트에서 import
    sys.path.insert(0, project_root)
    from grpc_data_manager import grpc_data_manager
    
    GRPC_CLIENT_AVAILABLE = True
    print("[WIFI_UI] ✅ gRPC 클라이언트 로드 성공!")
    
except Exception as e:
    GRPC_CLIENT_AVAILABLE = False
    print(f"[WIFI_UI ERROR] gRPC 클라이언트 import 실패: {e}")
    
    # 더미 객체들 생성
    class DummyClient:
        @staticmethod
        def send_homing_command(*args, **kwargs):
            return "gRPC 연결 없음"
        @staticmethod
        def send_master_teleop_command(*args, **kwargs):
            return "gRPC 연결 없음"
        @staticmethod
        def send_power_off_command(*args, **kwargs):
            return "gRPC 연결 없음"
        @staticmethod
        def send_delete_command(*args, **kwargs):
            return "gRPC 연결 없음"
        @staticmethod
        def send_save_command(*args, **kwargs):
            return "gRPC 연결 없음"
    
    client = DummyClient()
    
    # 더미 grpc_data_manager
    class DummyGRPCDataManager:
        def get_current_encoder_data(self):
            return None
        def save_encoder_pose(self, *args, **kwargs):
            return "Dummy_Pose"
        def get_saved_poses(self):
            return []
        def clear_poses(self):
            pass
        def delete_recorded_data(self):
            pass
        def get_recorded_log(self, limit):
            return []
        def get_robot_state(self):
            return {"connected": False, "hardware_buttons": {}, "communication": {}, "recording": {}, "gravity": {}, "position": {}}
        def get_grpc_entries(self, limit):
            return []
        def get_encoder_entries(self, limit):
            return []
    
    grpc_data_manager = DummyGRPCDataManager()

# ===============================
# 설정 및 상수
# ===============================
# 라즈베리파이 연결 정보 (임시값, 실제로는 wifi.py에서 전달받음)
DEFAULT_RASPBERRY_IP = "192.168.0.43"
DEFAULT_RASPBERRY_PORT = 50051

# ===============================
# CSS 스타일 및 클래스 정의 (간소화)
# ===============================
def get_led_style(is_active: bool, color: str = "green") -> dict:
    """LED 스타일 반환"""
    return {
        'display': 'inline-block',
        'width': '12px',
        'height': '12px',
        'borderRadius': '50%',
        'backgroundColor': color if is_active else '#888',
        'boxShadow': f'0 0 6px {color}' if is_active else 'none',
        'transition': 'all 0.3s ease'
    }

def get_control_class(is_active: bool) -> str:
    """컨트롤 클래스 반환"""
    if is_active:
        return "text-success fw-bold"  # Bootstrap 클래스 사용
    else:
        return "text-muted"

def get_fps_class(fps: float) -> str:
    """FPS 표시 클래스 반환"""
    if fps > 5:
        return "badge bg-success"  # 양호한 연결
    else:
        return "badge bg-danger"   # 나쁜 연결

# ===============================
# 레이아웃 컴포넌트들
# ===============================

# 간단한 Wi-Fi 성공 화면
wifi_success_screen = dbc.Container([
    html.Div([
        html.H2("✅ Wi-Fi 연결 완료!",
                style={'textAlign': 'center', 'color': '#28a745', 'marginTop': '100px'}),
        html.P("마스터 디바이스 제어 화면으로 자동 이동합니다...",
               style={'textAlign': 'center', 'fontSize': '18px', 'marginTop': '20px'}),

        # 카운트다운 표시
        html.Div([
            html.Span("자동 이동까지: "),
            html.Span(id="wifi-countdown-number", children="3",
                      style={'fontWeight': 'bold', 'fontSize': '24px', 'color': '#007bff'}),
            html.Span("초")
        ], style={'textAlign': 'center', 'marginTop': '30px', 'fontSize': '16px'}),

        # Wi-Fi 연결 정보
        html.Div(id="wifi-show-wifi-info",
                 style={'textAlign': 'center', 'marginTop': '20px', 'fontWeight': 'bold'}),

        # 수동 이동 버튼
        html.Div([
            dbc.Button("지금 바로 이동", id="wifi-manual-go-btn", color="primary",
                       style={'marginTop': '20px', 'marginRight': '10px'}),
            html.Br(),
            dcc.Link("← Wi-Fi 메뉴로 돌아가기", href="/wifi",
                     className="btn btn-link", style={'marginTop': '10px'})
        ], style={'textAlign': 'center'}),
    ])
], fluid=True)

# 메인 제어 화면
main_control_screen = html.Div([

    # 헤더
    html.Div([
        html.Img(src="/assets/Neuro_Meka.png", style={'height': '60px'}),
        html.H2("Neuro Meka Master device (Wi-Fi Connected)",
                style={'color': '#7c8bc7', 'fontWeight': 'bold', 'marginLeft': '20px'})
    ], style={'display': 'flex', 'alignItems': 'center',
              'borderBottom': '2px solid #ccc', 'paddingBottom': '10px'}),

    # 연결 상태 표시
    dbc.Alert(id="wifi-connection-status", color="success", className="mt-3"),

    # Encoder List 카드
    dcc.Store(id="wifi-saved-entries", data=[]),
    dbc.Card([
        dbc.CardHeader([
            html.H5("Encoder List", className="mb-0", style={'display': 'inline-block'}),
            html.Div(id="wifi-encoder-status-indicator", style={'float': 'right'})
        ]),
        dbc.CardBody([
            # 하드웨어 버튼 상태 표시
            html.Div([
                html.Span("🎮 Hardware Controls: ", style={'fontWeight': 'bold'}),
                html.Span("R_push_1: ", style={'fontSize': '0.9em'}),
                html.Span(id="wifi-r-push1-status", children="1",
                          style={'fontWeight': 'bold', 'color': 'blue'}),
                html.Span(" | L_push_1: ", style={'fontSize': '0.9em', 'marginLeft': '10px'}),
                html.Span(id="wifi-l-push1-status", children="1",
                          style={'fontWeight': 'bold', 'color': 'blue'}),
                html.Span(" | L_push_2: ", style={'fontSize': '0.9em', 'marginLeft': '10px'}),
                html.Span(id="wifi-l-push2-status", children="1",
                          style={'fontWeight': 'bold', 'color': 'blue'}),
            ], style={'marginBottom': '10px', 'padding': '5px',
                      'backgroundColor': '#f8f9fa', 'borderRadius': '3px'}),

            # 컨트롤 버튼들 (기존 + 추가)
            html.Div([
                dbc.Button("Save", id="wifi-save-btn", color="primary", className="me-2"),
                dbc.Button("Clear", id="wifi-clear-btn", color="danger", className="me-2"),
                dbc.Button("Save As", id="wifi-save-as-btn", color="secondary", className="me-2"),
                dbc.Button("Import Recorded", id="wifi-import-recorded-btn", color="success", className="me-2"),
                dbc.Button("Clear Recorded", id="wifi-clear-recorded-btn", color="warning", className="me-2"),
            ], className="mb-2"),

            # 추가 제어 버튼들 (새로 추가)
            html.Div([
                dbc.Button("Go Home", id="wifi-go-home-btn", color="info", className="me-2"),
                dbc.Button("Start Teleop", id="wifi-start-teleop-btn", color="success", className="me-2"),
                dbc.Button("Stop Teleop", id="wifi-stop-teleop-btn", color="danger", className="me-2"),
                dbc.Button("Delete All", id="wifi-delete-all-btn", color="warning", className="me-2"),
                dbc.Button("Power Off", id="wifi-power-off-btn", color="dark", className="me-2"),
            ], className="mb-3"),

            html.Div(id="wifi-save-as-status", style={'marginTop': '10px'}),
            html.Div(id="wifi-import-status", style={'marginTop': '5px'}),
            html.Div(id="wifi-control-status", style={'marginTop': '5px'}),
            html.Div(id="wifi-save-status", style={'marginTop': '5px'}),
            html.Div(id="wifi-clear-status", style={'marginTop': '5px'}),
            html.Hr(),

            # 통신 속도 및 녹화 상태 표시
            html.Div([
                html.Span("📊 Communication: ", style={'fontWeight': 'bold'}),
                html.Span(id="wifi-comm-fps", children="0 FPS", className="fps-indicator connection-bad"),
                html.Span(" | Interval: "),
                html.Span(id="wifi-comm-interval", children="0ms", style={'color': 'blue'}),
                html.Span(" | Recording: "),
                html.Span(id="wifi-recording-status", children="STOPPED",
                          style={'color': 'red', 'fontWeight': 'bold'}),
            ], style={'marginBottom': '10px', 'fontSize': '0.9em', 'color': '#666'}),

            html.Div(id="wifi-encoder-list-display",
                     style={'height': '200px', 'overflowY': 'auto', 'border': '1px solid #dee2e6',
                            'borderRadius': '5px', 'padding': '10px'})
        ])
    ], className="mt-4 status-card"),

    # 실시간 기록된 엔코더 로그
    dbc.Card([
        dbc.CardHeader([
            html.H5("Live Encoder Log", className="mb-0", style={'display': 'inline-block'}),
            html.Div(id="wifi-log-count-indicator",
                     style={'float': 'right', 'fontSize': '0.9em', 'color': '#6c757d'})
        ]),
        dbc.CardBody(
            html.Div(id="wifi-recorded-list-display",
                     style={'height': '200px', 'overflowY': 'auto',
                            'fontFamily': 'monospace', 'fontSize': '0.8em',
                            'border': '1px solid #dee2e6', 'borderRadius': '5px', 'padding': '10px'})
        )
    ], className="mt-4 status-card"),

    # 로봇 상태 표시 (왼팔/오른팔)
    dbc.Row([
        dbc.Col(
            dbc.Card([
                dbc.CardHeader("왼팔 상태"),
                dbc.CardBody(
                    html.Div([
                        html.Div([
                            html.Span(id="wifi-led-left-pos", className="me-2"),
                            html.Span("Position Control", id="wifi-pos-left", className="control-inactive")
                        ], className="d-flex align-items-center mb-2"),

                        html.Div([
                            html.Span(id="wifi-led-left-grav", className="me-2"),
                            html.Span("Gravity Control", id="wifi-grav-left", className="control-inactive")
                        ], className="d-flex align-items-center")
                    ], className="d-flex flex-column")
                )
            ], className="h-100 status-card"),
            xs=12, md=6
        ),

        dbc.Col(
            dbc.Card([
                dbc.CardHeader("오른팔 상태"),
                dbc.CardBody(
                    html.Div([
                        html.Div([
                            html.Span(id="wifi-led-right-pos", className="me-2"),
                            html.Span("Position Control", id="wifi-pos-right", className="control-inactive")
                        ], className="d-flex align-items-center mb-2"),

                        html.Div([
                            html.Span(id="wifi-led-right-grav", className="me-2"),
                            html.Span("Gravity Control", id="wifi-grav-right", className="control-inactive")
                        ], className="d-flex align-items-center")
                    ], className="d-flex flex-column")
                )
            ], className="h-100 status-card"),
            xs=12, md=6
        ),
    ], className="g-3 mt-3"),

    # Master Device Pairing 상태
    dbc.Row([
        dbc.Col(
            dbc.Card([
                dbc.CardHeader("Master Device Pairing (Wi-Fi)"),
                dbc.CardBody(
                    html.Div([
                        html.Span(id="wifi-pairing-indicator", className="me-2"),
                        dbc.Button(id="wifi-pairing-btn", disabled=True, className="me-3"),
                        html.Div(
                            id="wifi-grpc-enc-display",
                            style={'fontFamily': 'monospace', 'whiteSpace': 'pre', 'fontSize': '0.85em'}
                        )
                    ], className="d-flex align-items-center")
                )
            ], className="h-100 status-card"),
            xs=12, md=12
        ),
    ], className="g-3 mt-3"),

    # Live gRPC Encoder List
    dcc.Store(id="wifi-grpc-entries", data=[]),
    dbc.Card([
        dbc.CardHeader([
            html.H5("Live gRPC Log", className="mb-0", style={'display': 'inline-block'}),
            html.Div(id="wifi-grpc-log-indicator",
                     style={'float': 'right', 'fontSize': '0.9em', 'color': '#6c757d'})
        ]),
        dbc.CardBody([
            html.Div(
                id="wifi-grpc-list-display",
                style={
                    'height': '150px',
                    'overflowY': 'auto',
                    'fontFamily': 'monospace',
                    'whiteSpace': 'pre-wrap',
                    'fontSize': '0.8em',
                    'border': '1px solid #dee2e6',
                    'borderRadius': '5px',
                    'padding': '10px'
                }
            )
        ])
    ], className="mt-4 status-card"),

    # 주기적 업데이트 트리거
    dcc.Interval(id="wifi-interval", interval=100, n_intervals=0),  # 100ms = 10Hz

    html.Br(),
    dcc.Link("← Wi-Fi 메뉴로 돌아가기", href="/wifi", className="btn btn-link")
], style={'padding': '20px'})

# 메인 레이아웃 (CSS 제거)
layout = html.Div([
    # 페이지 상태 저장
    dcc.Store(id="wifi-page-state", data={"current_view": "wifi_success"}),

    # 라즈베리파이 연결 정보 저장
    dcc.Store(id="wifi-raspberry-connection", data={
        "ip": DEFAULT_RASPBERRY_IP,
        "port": DEFAULT_RASPBERRY_PORT
    }),

    # 자동 연결 시도 플래그
    dcc.Store(id="wifi-auto-connect-attempted", data=False),

    # 메인 콘텐츠
    html.Div(id="wifi-main-content", children=wifi_success_screen),

    # 타이머 (1초마다 실행, 최대 4초)
    dcc.Interval(id="wifi-auto-timer", interval=1000, n_intervals=0, max_intervals=4)
])

# ===============================
# 콜백 함수들
# ===============================

# 자동 전환 타이머 콜백
@callback(
    [Output("wifi-countdown-number", "children"),
     Output("wifi-main-content", "children"),
     Output("wifi-page-state", "data")],
    [Input("wifi-auto-timer", "n_intervals"),
     Input("wifi-manual-go-btn", "n_clicks")],
    State("wifi-page-state", "data")
)
def handle_auto_transition(n_intervals, manual_click, page_state):
    """자동 화면 전환 처리"""
    ctx = dash.callback_context

    if not ctx.triggered:
        return "3", no_update, no_update

    trigger_id = ctx.triggered[0]['prop_id'].split('.')[0]

    # 수동 이동 버튼 클릭
    if trigger_id == "wifi-manual-go-btn" and manual_click:
        return "0", main_control_screen, {"current_view": "main_control"}

    # 자동 타이머
    if trigger_id == "wifi-auto-timer":
        remaining = 3 - n_intervals
        if remaining <= 0:
            return "0", main_control_screen, {"current_view": "main_control"}
        else:
            return str(remaining), no_update, no_update

    return no_update, no_update, no_update

# 자동 Connect 전송 콜백
@callback(
    [Output("wifi-connection-status", "children"),
     Output("wifi-connection-status", "color"),
     Output("wifi-auto-connect-attempted", "data")],
    Input("wifi-page-state", "data"),
    [State("wifi-raspberry-connection", "data"),
     State("wifi-auto-connect-attempted", "data")],
    prevent_initial_call=True
)
def auto_connect_to_raspberry(page_state, connection_data, attempted):
    """메인 화면 진입 시 자동으로 라즈베리파이에 Connect 전송"""
    if page_state.get("current_view") != "main_control" or attempted:
        return no_update, no_update, no_update
    
    if not GRPC_CLIENT_AVAILABLE:
        return "❌ gRPC 클라이언트 모듈이 없습니다", "danger", True
    
    try:
        ip = connection_data.get("ip", DEFAULT_RASPBERRY_IP)
        port = connection_data.get("port", DEFAULT_RASPBERRY_PORT)
        
        # 라즈베리파이에 Connect 명령 전송
        response = client.send_connect_command(ip, port, "WIFI_UI_CONNECT")
        
        if "성공" in response or "success" in response.lower():
            return f"✅ 라즈베리파이 연결 성공: {ip}:{port}", "success", True
        else:
            return f"⚠️ 연결 응답: {response}", "warning", True
            
    except Exception as e:
        return f"❌ 자동 연결 실패: {str(e)}", "danger", True

# 메인 상태 업데이트 콜백
@callback(
    [Output("wifi-r-push1-status", "children"),
     Output("wifi-l-push1-status", "children"),
     Output("wifi-l-push2-status", "children"),
     Output("wifi-comm-fps", "children"),
     Output("wifi-comm-fps", "className"),
     Output("wifi-comm-interval", "children"),
     Output("wifi-recording-status", "children"),
     Output("wifi-recording-status", "className"),
     Output("wifi-pairing-indicator", "style"),
     Output("wifi-pairing-btn", "children"),
     Output("wifi-pairing-btn", "color"),
     Output("wifi-pairing-btn", "disabled")],
    Input("wifi-interval", "n_intervals"),
    State("wifi-page-state", "data")
)
def update_main_status(n_intervals, page_state):
    """메인 상태 정보 업데이트"""
    if page_state.get("current_view") != "main_control":
        return (no_update,) * 12

    try:
        # 로봇 상태 가져오기
        robot_state = grpc_data_manager.get_robot_state()
        hardware_buttons = robot_state.get("hardware_buttons", {})
        communication = robot_state.get("communication", {})
        recording = robot_state.get("recording", {})
        connected = robot_state.get("connected", False)

        # 하드웨어 버튼 상태
        r_push1 = hardware_buttons.get("r_push_1", 1)
        l_push1 = hardware_buttons.get("l_push_1", 1)
        l_push2 = hardware_buttons.get("l_push_2", 1)

        # 통신 상태
        fps = communication.get("fps", 0.0)
        fps_text = f"{fps:.1f} FPS"
        fps_class = get_fps_class(fps)  # 새로운 함수 사용

        interval_ms = int(1000 / fps) if fps > 0 else 0
        interval_text = f"{interval_ms}ms"

        # 녹화 상태
        is_recording = recording.get("active", False)
        recording_text = "RECORDING" if is_recording else "STOPPED"
        recording_class = "text-danger fw-bold" if is_recording else "text-secondary"

        # 페어링 상태
        pairing_led_style = get_led_style(connected, "#28a745")
        pairing_btn_text = "Connected" if connected else "Disconnected"
        pairing_btn_color = "success" if connected else "danger"

        return (
            str(r_push1), str(l_push1), str(l_push2),  # 하드웨어 버튼
            fps_text, fps_class, interval_text,        # 통신 상태
            recording_text, recording_class,           # 녹화 상태
            pairing_led_style, pairing_btn_text, pairing_btn_color, True  # 페어링 상태
        )

    except Exception as e:
        print(f"[ERROR] 상태 업데이트 오류: {e}")
        return (
            "?", "?", "?",  # 하드웨어 버튼
            "0 FPS", "badge bg-danger", "0ms",  # 통신 상태 (Bootstrap 클래스)
            "ERROR", "text-danger",  # 녹화 상태
            get_led_style(False), "Error", "danger", True  # 페어링 상태
        )

# 로봇 컨트롤 상태 업데이트 콜백
@callback(
    [Output("wifi-led-left-pos", "style"),
     Output("wifi-pos-left", "className"),
     Output("wifi-led-left-grav", "style"),
     Output("wifi-grav-left", "className"),
     Output("wifi-led-right-pos", "style"),
     Output("wifi-pos-right", "className"),
     Output("wifi-led-right-grav", "style"),
     Output("wifi-grav-right", "className")],
    Input("wifi-interval", "n_intervals"),
    State("wifi-page-state", "data")
)
def update_robot_control_status(n_intervals, page_state):
    """로봇 컨트롤 상태 업데이트"""
    if page_state.get("current_view") != "main_control":
        return (no_update,) * 8

    try:
        robot_state = grpc_data_manager.get_robot_state()
        gravity_state = robot_state.get("gravity", {})
        position_state = robot_state.get("position", {})

        # 왼팔 상태
        left_pos_active = position_state.get("left", {}).get("active", False)
        left_grav_active = gravity_state.get("left", {}).get("active", False)

        # 오른팔 상태
        right_pos_active = position_state.get("right", {}).get("active", False)
        right_grav_active = gravity_state.get("right", {}).get("active", False)

        return (
            get_led_style(left_pos_active, "#007bff"), get_control_class(left_pos_active),   # 왼팔 Position
            get_led_style(left_grav_active, "#28a745"), get_control_class(left_grav_active), # 왼팔 Gravity
            get_led_style(right_pos_active, "#007bff"), get_control_class(right_pos_active), # 오른팔 Position
            get_led_style(right_grav_active, "#28a745"), get_control_class(right_grav_active) # 오른팔 Gravity
        )

    except Exception as e:
        print(f"[ERROR] 로봇 컨트롤 상태 업데이트 오류: {e}")
        # 모든 LED 비활성화
        inactive_led = get_led_style(False)
        inactive_class = get_control_class(False)
        return (inactive_led, inactive_class) * 4

# 엔코더 데이터 표시 콜백
@callback(
    [Output("wifi-encoder-list-display", "children"),
     Output("wifi-encoder-status-indicator", "children"),
     Output("wifi-grpc-enc-display", "children")],
    Input("wifi-interval", "n_intervals"),
    State("wifi-page-state", "data")
)
def update_encoder_display(n_intervals, page_state):
    """엔코더 데이터 표시 업데이트"""
    if page_state.get("current_view") != "main_control":
        return no_update, no_update, no_update

    try:
        # 저장된 포즈 목록
        saved_poses = grpc_data_manager.get_saved_poses()

        # 현재 엔코더 데이터
        current_encoder = grpc_data_manager.get_current_encoder_data()

        # 최근 엔코더 엔트리들
        encoder_entries = grpc_data_manager.get_encoder_entries(10)

        # 저장된 포즈 표시
        pose_children = []
        for i, pose in enumerate(saved_poses[:10]):  # 최근 10개만
            angles_str = ", ".join([f"{a:.1f}°" for a in pose["angles"]])
            pose_children.append(
                html.Div([
                    html.Strong(f"{pose['name']}: ", style={'color': '#007bff'}),
                    html.Span(f"[{angles_str}] ", style={'fontFamily': 'monospace'}),
                    html.Small(f"({pose['timestamp']})", style={'color': '#6c757d'})
                ], className="encoder-row")
            )

        if not pose_children:
            pose_children = [html.Div("저장된 포즈가 없습니다.", style={'color': '#6c757d', 'fontStyle': 'italic'})]

        # 상태 표시기
        status_indicator = html.Span(f"💾 {len(saved_poses)}개 포즈 저장됨",
                                     style={'fontSize': '0.9em', 'color': '#28a745'})

        # 현재 엔코더 데이터 표시
        if current_encoder:
            angles_str = ", ".join([f"{a:.1f}°" for a in current_encoder["angles"][:6]])
            enc_display = f"Current: [{angles_str}]\nSample #{current_encoder['sample_id']} at {current_encoder['timestamp']}"
        else:
            enc_display = "엔코더 데이터 없음"

        return pose_children, status_indicator, enc_display

    except Exception as e:
        print(f"[ERROR] 엔코더 표시 업데이트 오류: {e}")
        return [html.Div("데이터 로드 오류", style={'color': 'red'})], "", "오류"

# 로그 표시 콜백
@callback(
    [Output("wifi-recorded-list-display", "children"),
     Output("wifi-log-count-indicator", "children"),
     Output("wifi-grpc-list-display", "children"),
     Output("wifi-grpc-log-indicator", "children")],
    Input("wifi-interval", "n_intervals"),
    State("wifi-page-state", "data")
)
def update_logs_display(n_intervals, page_state):
    """로그 표시 업데이트"""
    if page_state.get("current_view") != "main_control":
        return no_update, no_update, no_update, no_update

    try:
        # 녹화 로그
        recorded_log = grpc_data_manager.get_recorded_log(50)
        recorded_children = []
        for log_entry in recorded_log[-20:]:  # 최근 20개만 표시
            recorded_children.append(html.Div(log_entry, className="log-entry"))

        if not recorded_children:
            recorded_children = [html.Div("녹화 로그가 없습니다.", style={'color': '#6c757d', 'fontStyle': 'italic'})]

        # gRPC 로그
        grpc_entries = grpc_data_manager.get_grpc_entries(30)
        grpc_children = []
        for entry in grpc_entries[:15]:  # 최근 15개만 표시
            color = "#dc3545" if entry["level"] == "ERROR" else "#6c757d"
            grpc_children.append(
                html.Div(f"[{entry['timestamp']}] {entry['topic']}: {entry['message']}",
                         className="log-entry",
                         style={'color': color})
            )

        if not grpc_children:
            grpc_children = [html.Div("gRPC 로그가 없습니다.", style={'color': '#6c757d', 'fontStyle': 'italic'})]

        # 카운터 표시
        log_count = f"📝 {len(recorded_log)}개"
        grpc_count = f"📡 {len(grpc_entries)}개"

        return recorded_children, log_count, grpc_children, grpc_count

    except Exception as e:
        print(f"[ERROR] 로그 표시 업데이트 오류: {e}")
        error_msg = [html.Div("로그 로드 오류", style={'color': 'red'})]
        return error_msg, "❌", error_msg, "❌"

# ════════════════════════════════════════════════════════════════════════════════════════
# Save As 및 Import Recorded 버튼 처리 (Output 분리)
@callback(
    Output("wifi-save-as-status", "children"),
    Input("wifi-save-as-btn", "n_clicks"),
    [State("wifi-raspberry-connection", "data")],
    prevent_initial_call=True
)
def handle_save_as_button(save_as_clicks, connection_data):
    """Save As 버튼 처리"""
    if not save_as_clicks:
        return no_update
    
    try:
        # Save As 기능 - 현재 엔코더 데이터를 커스텀 이름으로 저장
        current_encoder = grpc_data_manager.get_current_encoder_data()
        if current_encoder:
            # 시간 기반 이름 생성
            custom_name = f"Custom_{time.strftime('%H%M%S')}"
            pose_name = grpc_data_manager.save_encoder_pose(current_encoder["angles"], custom_name)
            return dbc.Alert(f"✅ 커스텀 포즈 저장: {pose_name}", color="success", duration=3000)
        else:
            return dbc.Alert("❌ 저장할 엔코더 데이터가 없습니다.", color="warning", duration=3000)
    except Exception as e:
        return dbc.Alert(f"❌ 처리 실패: {str(e)}", color="danger", duration=3000)

@callback(
    Output("wifi-import-status", "children"),
    Input("wifi-import-recorded-btn", "n_clicks"),
    [State("wifi-raspberry-connection", "data")],
    prevent_initial_call=True
)
def handle_import_recorded_button(import_clicks, connection_data):
    """Import Recorded 버튼 처리"""
    if not import_clicks:
        return no_update
    
    try:
        # Import Recorded 기능 - 녹화된 로그를 포즈로 변환
        recorded_log = grpc_data_manager.get_recorded_log(100)
        if len(recorded_log) > 0:
            # 최근 녹화 데이터를 포즈로 저장
            current_encoder = grpc_data_manager.get_current_encoder_data()
            if current_encoder:
                import_name = f"Imported_{time.strftime('%H%M%S')}"
                pose_name = grpc_data_manager.save_encoder_pose(current_encoder["angles"], import_name)
                
                # 라즈베리파이에도 저장 명령 전송
                if GRPC_CLIENT_AVAILABLE and connection_data:
                    ip = connection_data.get("ip", DEFAULT_RASPBERRY_IP)
                    port = connection_data.get("port", DEFAULT_RASPBERRY_PORT)
                    client.send_save_command(ip, port, angles=current_encoder["angles"])
                
                return dbc.Alert(f"✅ 녹화 데이터 가져오기 완료: {pose_name}", color="success", duration=3000)
            else:
                return dbc.Alert("❌ 가져올 녹화 데이터가 없습니다.", color="warning", duration=3000)
        else:
            return dbc.Alert("❌ 녹화된 로그가 없습니다.", color="warning", duration=3000)
    except Exception as e:
        return dbc.Alert(f"❌ 처리 실패: {str(e)}", color="danger", duration=3000)

# Save 버튼 처리 (고유한 Output 사용) — ※ 중복 Output 제거 완료
@callback(
    Output("wifi-save-status", "children"),
    Input("wifi-save-btn", "n_clicks"),
    prevent_initial_call=True
)
def handle_save_button(n_clicks):
    """Save 버튼 처리"""
    if not n_clicks:
        return no_update

    try:
        # 현재 엔코더 데이터로 포즈 저장
        current_encoder = grpc_data_manager.get_current_encoder_data()
        if current_encoder:
            pose_name = grpc_data_manager.save_encoder_pose(current_encoder["angles"])
            return dbc.Alert(f"✅ 포즈 저장 완료: {pose_name}", color="success", duration=3000)
        else:
            return dbc.Alert("❌ 저장할 엔코더 데이터가 없습니다.", color="warning", duration=3000)
    except Exception as e:
        return dbc.Alert(f"❌ 저장 실패: {str(e)}", color="danger", duration=3000)

# Clear 버튼 처리 (고유한 Output 사용)
@callback(
    Output("wifi-clear-status", "children"),
    Input("wifi-clear-btn", "n_clicks"),
    prevent_initial_call=True
)
def handle_clear_button(n_clicks):
    """Clear 버튼 처리"""
    if not n_clicks:
        return no_update

    try:
        pose_count = len(grpc_data_manager.get_saved_poses())
        grpc_data_manager.clear_poses()
        return dbc.Alert(f"✅ {pose_count}개 저장된 포즈가 모두 삭제되었습니다.", color="info", duration=3000)
    except Exception as e:
        return dbc.Alert(f"❌ 삭제 실패: {str(e)}", color="danger", duration=3000)

# Clear Recorded / Go Home / Teleop / Delete All / Power Off
@callback(
    Output("wifi-control-status", "children"),
    [Input("wifi-clear-recorded-btn", "n_clicks"),
     Input("wifi-go-home-btn", "n_clicks"),
     Input("wifi-start-teleop-btn", "n_clicks"),
     Input("wifi-stop-teleop-btn", "n_clicks"),
     Input("wifi-delete-all-btn", "n_clicks"),
     Input("wifi-power-off-btn", "n_clicks")],
    [State("wifi-raspberry-connection", "data")],
    prevent_initial_call=True
)
def handle_control_buttons(clear_rec_clicks, home_clicks, start_teleop_clicks, stop_teleop_clicks, 
                          delete_all_clicks, power_off_clicks, connection_data):
    """제어 버튼들 처리"""
    ctx = dash.callback_context
    if not ctx.triggered:
        return no_update
    
    trigger_id = ctx.triggered[0]['prop_id'].split('.')[0]
    
    if not GRPC_CLIENT_AVAILABLE:
        return dbc.Alert("❌ gRPC 클라이언트 모듈이 없습니다.", color="danger", duration=3000)
    
    try:
        ip = connection_data.get("ip", DEFAULT_RASPBERRY_IP)
        port = connection_data.get("port", DEFAULT_RASPBERRY_PORT)
        
        if trigger_id == "wifi-clear-recorded-btn" and clear_rec_clicks:
            # 녹화 데이터 삭제
            grpc_data_manager.delete_recorded_data()
            return dbc.Alert("✅ 녹화된 데이터가 모두 삭제되었습니다.", color="info", duration=3000)
            
        elif trigger_id == "wifi-go-home-btn" and home_clicks:
            # Go Home 명령 전송 (server.cpp의 Homing RPC와 매칭)
            response = client.send_homing_command(ip, port, "GO_HOME")
            return dbc.Alert(f"🏠 홈 이동 명령 전송: {response}", color="info", duration=3000)
            
        elif trigger_id == "wifi-start-teleop-btn" and start_teleop_clicks:
            # 텔레오퍼레이션 시작 (server.cpp의 Teleoperation1 RPC와 매칭)
            response = client.send_master_teleop_command(ip, port, "START")
            return dbc.Alert(f"🎮 텔레오퍼레이션 시작: {response}", color="success", duration=3000)
            
        elif trigger_id == "wifi-stop-teleop-btn" and stop_teleop_clicks:
            # 텔레오퍼레이션 중지 (server.cpp의 Teleoperation1 RPC와 매칭)
            response = client.send_master_teleop_command(ip, port, "STOP")
            return dbc.Alert(f"⛔ 텔레오퍼레이션 중지: {response}", color="warning", duration=3000)
            
        elif trigger_id == "wifi-delete-all-btn" and delete_all_clicks:
            # 모든 데이터 삭제 (로컬 + 라즈베리파이)
            grpc_data_manager.reset_all_data()
            response = client.send_delete_command(ip, port, "ALL")
            return dbc.Alert(f"🗑️ 모든 데이터 삭제 완료: {response}", color="warning", duration=3000)
            
        elif trigger_id == "wifi-power-off-btn" and power_off_clicks:
            # 전원 종료 명령 전송 (server.cpp의 PowerOff RPC와 매칭)
            response = client.send_power_off_command(ip, port, "POWER_OFF")
            return dbc.Alert(f"🔌 전원 종료 명령 전송: {response}", color="dark", duration=5000)
    
    except Exception as e:
        return dbc.Alert(f"❌ 명령 전송 실패: {str(e)}", color="danger", duration=3000)
    
    return no_update
