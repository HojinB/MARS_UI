# app.py
from dash import Dash, dcc, html, Input, Output, State, dash, no_update
import dash_bootstrap_components as dbc
import serial.tools.list_ports
import serial
import sys
import os
import threading
import time
import grpc
from concurrent import futures
import signal
import atexit

# 페이지 레이아웃 가져오기
from pages import wifi_ui_1 as wifi_ui
from pages import usb, usb_ui, local, local_ui, wifi

# UI_TEST를 경로에 추가
sys.path.append(os.path.dirname(__file__))

# gRPC 데이터 매니저 import
from grpc_data_manager import grpc_data_manager

# GRPC 모듈 import
from GRPC.stubs import client

# ===============================
# gRPC 모듈 로드
# ===============================
try:
    from GRPC.stubs import masterdevice_pb2
    from GRPC.stubs import masterdevice_pb2_grpc
    GRPC_AVAILABLE = True
    print("[INFO] ✅ gRPC 모듈 로드 성공")
except ImportError as e:
    GRPC_AVAILABLE = False
    print(f"[WARNING] ⚠️ gRPC 관련 모듈을 찾을 수 없습니다: {e}")

# ===============================
# 네트워크 설정
# ===============================
LOCAL_IP = "192.168.0.4"     # PC IP 고정
WEB_SERVER_PORT = 8050       # 웹서버 포트 (Dash)
GRPC_SERVER_PORT = 50052     # gRPC 서버 포트 (라즈베리파이→PC용, 50051에서 변경)

print(f"[INFO] 🖥️ PC IP: {LOCAL_IP}")
print(f"[INFO] 🌐 웹서버 포트: {WEB_SERVER_PORT}")
print(f"[INFO] 🤖 gRPC 서버 포트: {GRPC_SERVER_PORT}")

# 전역 gRPC 서버 인스턴스 (정리용)
_grpc_server = None

# ===============================
# PC gRPC 서비스 구현 (라즈베리파이→PC용)
# ===============================
if GRPC_AVAILABLE:
    class PCGRPCServiceImpl(masterdevice_pb2_grpc.masterdeviceServicer):
        """PC에서 실행되는 gRPC 서비스 - 라즈베리파이로부터 상태/데이터 수신"""

        def __init__(self):
            self.request_count = 0
            self.enable_data_manager = True
            print("🤖 PC gRPC 서비스 초기화 완료")

        def _log_request(self, method_name, request_data, client_addr=None):
            """요청 로깅 및 데이터 매니저에 기록"""
            self.request_count += 1
            timestamp = time.strftime("[%H:%M:%S]")

            # 클라이언트 IP 추출
            client_ip = "unknown"
            if client_addr:
                try:
                    # gRPC peer format: "ipv4:192.168.0.43:12345" 또는 "unix:/path"
                    parts = client_addr.split(':')
                    if len(parts) >= 2:
                        client_ip = parts[1] if parts[0] == "ipv4" else parts[-1]
                except:
                    client_ip = str(client_addr)

            # 콘솔 로그
            print(f"{timestamp} 🔥 요청 #{self.request_count} - {method_name}: {request_data}")
            print(f"    👤 클라이언트: {client_ip}")

            # 데이터 매니저에 기록 (UI에서 볼 수 있도록)
            log_message = f"[{method_name}] {request_data} (from {client_ip})"
            grpc_data_manager.add_grpc_entry("RECEIVED", log_message)

        # ────────────────────────────────────────────────────────────────────
        #  Connect (unary)
        # ────────────────────────────────────────────────────────────────────
        def Connect(self, request, context):
            self._log_request("Connect", request.command, context.peer())

            try:
                grpc_data_manager.connect_client(request.command)
                response_msg = "connect rpc: success - PC UI 서버 연결 성공"
                print(f"    ✅ 라즈베리파이 클라이언트 연결됨")
                return masterdevice_pb2.ConnectMessage(message=response_msg)
            except Exception as e:
                print(f"    ❌ 연결 처리 오류: {e}")
                grpc_data_manager.add_grpc_entry("ERROR", f"연결 실패: {str(e)}")
                return masterdevice_pb2.ConnectMessage(message=f"연결 실패: {str(e)}")

        # ────────────────────────────────────────────────────────────────────
        #  Gravity (unary) — ON이면 Position을 ALL_OFF로 강제 (상호배타)
        # ────────────────────────────────────────────────────────────────────
        def GravityMode(self, request, context):
            self._log_request("GravityMode", request.command, context.peer())

            try:
                grpc_data_manager.set_gravity_mode(request.command)
                # ✅ 상호배타 보장: Gravity ON 켜지면 Position은 끄기
                if "ON" in request.command.upper():
                    grpc_data_manager.set_position_mode("ALL_OFF")
                    grpc_data_manager.add_grpc_entry("MUTEX", f"Gravity {request.command} → Position ALL_OFF")
                
                print(f"    🌍 Gravity 모드 업데이트: {request.command}")
                return masterdevice_pb2.GravityReply()  # message 필드 없음
            except Exception as e:
                print(f"    ❌ Gravity 모드 오류: {e}")
                grpc_data_manager.add_grpc_entry("ERROR", f"Gravity 모드 오류: {str(e)}")
                return masterdevice_pb2.GravityReply()

        # ────────────────────────────────────────────────────────────────────
        #  Position (unary) — ON이면 Gravity를 ALL_OFF로 강제 (상호배타)
        # ────────────────────────────────────────────────────────────────────
        def PositionMode(self, request, context):
            self._log_request("PositionMode", request.command, context.peer())

            try:
                grpc_data_manager.set_position_mode(request.command)
                # ✅ 상호배타 보장: Position ON 켜지면 Gravity는 끄기
                if "ON" in request.command.upper():
                    grpc_data_manager.set_gravity_mode("ALL_OFF")
                    grpc_data_manager.add_grpc_entry("MUTEX", f"Position {request.command} → Gravity ALL_OFF")
                
                print(f"    📍 Position 모드 업데이트: {request.command}")
                return masterdevice_pb2.PositionReply()  # message 필드 없음
            except Exception as e:
                print(f"    ❌ Position 모드 오류: {e}")
                grpc_data_manager.add_grpc_entry("ERROR", f"Position 모드 오류: {str(e)}")
                return masterdevice_pb2.PositionReply()

        # ────────────────────────────────────────────────────────────────────
        #  Save (client-streaming) — 포즈 저장 및 녹화 제어
        # ────────────────────────────────────────────────────────────────────
        def Save(self, request_iterator, context):
            """Save 처리 - client-streaming 방식 (올바른 proto에 맞춤)"""
            self._log_request("Save", "stream start", context.peer())

            total_msgs = 0
            last_action = "NONE"

            try:
                for req in request_iterator:
                    total_msgs += 1
                    cmd = getattr(req, "command", "") or ""
                    has_angles = len(getattr(req, "angle", [])) > 0

                    if cmd == "SAVE_START":
                        grpc_data_manager.start_recording()
                        last_action = "SAVE_START"
                        grpc_data_manager.add_grpc_entry("SAVE", "녹화 시작")
                        print("    🔹 SAVE_START")
                    elif cmd == "SAVE_STOP":
                        pose_name = grpc_data_manager.stop_recording()
                        last_action = f"SAVE_STOP:{pose_name}"
                        grpc_data_manager.add_grpc_entry("SAVE", f"녹화 종료: {pose_name}")
                        print(f"    💾 SAVE_STOP → {pose_name}")
                    elif has_angles:
                        angles = list(req.angle)
                        pose_name = grpc_data_manager.save_encoder_pose(angles)
                        last_action = f"SAVE_ANGLES:{pose_name}"
                        grpc_data_manager.add_grpc_entry("SAVE", f"각도 저장: {pose_name} ({len(angles)}개)")
                        print(f"    💾 각도 저장 완료: {pose_name}")
                    else:
                        grpc_data_manager.add_grpc_entry("SAVE", f"알 수 없는 메시지 #{total_msgs}")

                # 스트림 종료
                print(f"    ✅ Save stream end, total msgs={total_msgs}, last={last_action}")
                return masterdevice_pb2.SaveReply()  # message 필드 없음
            except Exception as e:
                print(f"    ❌ Save 스트림 처리 오류: {e}")
                grpc_data_manager.add_grpc_entry("ERROR", f"Save 스트림 오류: {str(e)}")
                return masterdevice_pb2.SaveReply()

        # ────────────────────────────────────────────────────────────────────
        #  Homing (unary) — 홈 위치로 이동
        # ────────────────────────────────────────────────────────────────────
        def Homing(self, request, context):
            self._log_request("Homing", request.command, context.peer())

            try:
                if request.command == "GO_HOME":
                    message = "홈 위치 도달 완료"
                    print("    🏠 홈 위치로 이동 시작")
                    grpc_data_manager.add_grpc_entry("HOMING", "GO_HOME 명령 수신 - 홈 위치로 이동")
                elif "HOMING_START" in request.command:
                    message = "홈 캘리브레이션 시작"
                    print("    🔧 홈 캘리브레이션 시작")
                    grpc_data_manager.add_grpc_entry("HOMING", "홈 캘리브레이션 시작")
                elif "HOMING_COMPLETE" in request.command:
                    message = "홈 캘리브레이션 완료"
                    print("    ✅ 홈 캘리브레이션 완료")
                    grpc_data_manager.add_grpc_entry("HOMING", "홈 캘리브레이션 완료")
                else:
                    message = f"홈 이동 처리 완료: {request.command}"
                    grpc_data_manager.add_grpc_entry("HOMING", f"홈 명령: {request.command}")

                print(f"    ✅ {message}")
                return masterdevice_pb2.HomingReply(message=message)
            except Exception as e:
                print(f"    ❌ 홈 이동 오류: {e}")
                grpc_data_manager.add_grpc_entry("ERROR", f"홈 이동 오류: {str(e)}")
                return masterdevice_pb2.HomingReply(message=f"홈 이동 실패: {str(e)}")

        # ────────────────────────────────────────────────────────────────────
        #  Teleoperation1 (unary) — 텔레오퍼레이션 시작/중지 제어
        # ────────────────────────────────────────────────────────────────────
        def Teleoperation1(self, request, context):
            self._log_request("Teleoperation1", request.command, context.peer())

            try:
                if request.command == "START":
                    message = "텔레오퍼레이션 시작됨"
                    print("    🎮 텔레오퍼레이션 시작")
                    grpc_data_manager.add_grpc_entry("TELEOP", "텔레오퍼레이션 START")
                elif request.command == "STOP":
                    message = "텔레오퍼레이션 중지됨"
                    print("    ⛔ 텔레오퍼레이션 중지")
                    grpc_data_manager.add_grpc_entry("TELEOP", "텔레오퍼레이션 STOP")
                elif request.command == "PAUSE":
                    message = "텔레오퍼레이션 일시정지됨"
                    print("    ⏸️ 텔레오퍼레이션 일시정지")
                    grpc_data_manager.add_grpc_entry("TELEOP", "텔레오퍼레이션 PAUSE")
                elif request.command == "RESUME":
                    message = "텔레오퍼레이션 재개됨"
                    print("    ▶️ 텔레오퍼레이션 재개")
                    grpc_data_manager.add_grpc_entry("TELEOP", "텔레오퍼레이션 RESUME")
                else:
                    message = f"텔레오퍼레이션 처리됨: {request.command}"
                    grpc_data_manager.add_grpc_entry("TELEOP", f"텔레오퍼레이션 명령: {request.command}")

                return masterdevice_pb2.TeleoperationMessage1(message=message)
            except Exception as e:
                print(f"    ❌ 텔레오퍼레이션 오류: {e}")
                grpc_data_manager.add_grpc_entry("ERROR", f"텔레오퍼레이션 오류: {str(e)}")
                return masterdevice_pb2.TeleoperationMessage1(message=f"텔레오퍼레이션 오류: {str(e)}")

        # ────────────────────────────────────────────────────────────────────
        #  Teleoperation2 (client-streaming) — 10Hz 엔코더 스트림
        # ────────────────────────────────────────────────────────────────────
        def Teleoperation2(self, request_iterator, context):
            self._log_request("Teleoperation2", "스트림 시작", context.peer())

            try:
                count = 0
                start_time = time.time()

                for request in request_iterator:
                    count += 1
                    angles = list(request.angle)
                    grpc_data_manager.update_encoder_data(angles)

                    # 주기적 로그 (2초마다 또는 20샘플마다) - 10Hz이므로 20샘플 = 2초
                    if count % 20 == 0:
                        elapsed = time.time() - start_time
                        fps = count / elapsed if elapsed > 0 else 0.0
                        print(f"    🎮 스트림 데이터 {count}: {len(angles)}개 관절, {fps:.1f} FPS")

                duration = time.time() - start_time
                fps = count / duration if duration > 0 else 0.0
                message = f"스트림 처리 완료: {count}개 데이터, {fps:.1f} FPS, {duration:.1f}초"
                print(f"    ✅ {message}")
                grpc_data_manager.add_grpc_entry("TELEOP_STREAM", message)
                return masterdevice_pb2.TeleoperationMessage2(message=message)
                
            except Exception as e:
                error_msg = f"스트림 처리 오류: {str(e)}"
                print(f"    ❌ {error_msg}")
                grpc_data_manager.add_grpc_entry("ERROR", error_msg)
                return masterdevice_pb2.TeleoperationMessage2(message=error_msg)

        # ────────────────────────────────────────────────────────────────────
        #  Delete (unary) — 저장된 데이터 삭제 기능 구현
        # ────────────────────────────────────────────────────────────────────
        def Delete(self, request, context):
            self._log_request("Delete", request.command, context.peer())

            try:
                command = request.command.upper()
                
                if "POSE" in command or "POSES" in command:
                    # 저장된 포즈 삭제
                    pose_count = len(grpc_data_manager.get_saved_poses())
                    grpc_data_manager.clear_poses()
                    message = f"포즈 데이터 삭제 완료: {pose_count}개"
                    print(f"    🗑️ 포즈 데이터 삭제 완료: {pose_count}개")
                    
                elif "RECORDED" in command or "LOG" in command:
                    # 녹화된 데이터 삭제
                    grpc_data_manager.delete_recorded_data()
                    message = "녹화 데이터 삭제 완료"
                    print(f"    🗑️ 녹화 데이터 삭제 완료")
                    
                elif "ALL" in command:
                    # 모든 데이터 삭제
                    grpc_data_manager.reset_all_data()
                    message = "모든 데이터 삭제 완료"
                    print(f"    🗑️ 모든 데이터 삭제 완료")
                    
                elif command.startswith("POSE_"):
                    # 특정 포즈 삭제 (예: "POSE_Pose_001")
                    pose_name = command[5:]  # "POSE_" 제거
                    if grpc_data_manager.delete_pose_by_name(pose_name):
                        message = f"포즈 '{pose_name}' 삭제 완료"
                        print(f"    🗑️ 특정 포즈 삭제 완료: {pose_name}")
                    else:
                        message = f"포즈 '{pose_name}'을 찾을 수 없음"
                        print(f"    ❌ 포즈를 찾을 수 없음: {pose_name}")
                        
                else:
                    message = f"알 수 없는 삭제 명령: {command}"
                    print(f"    ❌ 알 수 없는 삭제 명령: {command}")

                grpc_data_manager.add_grpc_entry("DELETE", message)
                return masterdevice_pb2.DeleteReply()  # message 필드 없음
                
            except Exception as e:
                error_msg = f"삭제 처리 오류: {str(e)}"
                print(f"    ❌ {error_msg}")
                grpc_data_manager.add_grpc_entry("ERROR", error_msg)
                return masterdevice_pb2.DeleteReply()

        # ────────────────────────────────────────────────────────────────────
        #  PowerOff (unary) — 시스템 전원 종료
        # ────────────────────────────────────────────────────────────────────
        def PowerOff(self, request, context):
            self._log_request("PowerOff", request.command, context.peer())

            try:
                if request.command == "POWER_OFF":
                    message = "시스템 종료 신호 처리됨"
                    grpc_data_manager.disconnect_client()
                    print(f"    🔌 시스템 전원 종료 신호")
                elif request.command == "SHUTDOWN":
                    message = "시스템 종료 준비 완료"
                    print(f"    🔌 시스템 종료 준비")
                elif request.command == "RESTART":
                    message = "시스템 재시작 준비 완료"
                    print(f"    🔄 시스템 재시작 준비")
                else:
                    message = f"전원 관리 처리됨: {request.command}"

                grpc_data_manager.add_grpc_entry("POWER", message)
                return masterdevice_pb2.PowerOffReply(message=message)
            except Exception as e:
                print(f"    ❌ 전원 관리 오류: {e}")
                grpc_data_manager.add_grpc_entry("ERROR", f"전원 관리 오류: {str(e)}")
                return masterdevice_pb2.PowerOffReply(message=f"전원 관리 실패: {str(e)}")


def start_pc_grpc_server():
    """PC gRPC 서버 시작 (라즈베리파이→PC용)"""
    global _grpc_server

    if not GRPC_AVAILABLE:
        print("⚠️ gRPC 모듈이 없어 gRPC 서버를 시작할 수 없습니다.")
        return

    try:
        _grpc_server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
        service_impl = PCGRPCServiceImpl()

        # 서비스 등록
        masterdevice_pb2_grpc.add_masterdeviceServicer_to_server(service_impl, _grpc_server)

        # 모든 인터페이스에서 수신 (라즈베리파이에서 연결 가능하도록)
        listen_addr = f'0.0.0.0:{GRPC_SERVER_PORT}'
        _grpc_server.add_insecure_port(listen_addr)

        print("=" * 60)
        print("🚀 PC gRPC 서버 시작")
        print("=" * 60)
        print(f"🖥️ PC IP: {LOCAL_IP}")
        print(f"🔌 gRPC 포트: {GRPC_SERVER_PORT}")
        print(f"📡 라즈베리파이 연결 주소: {LOCAL_IP}:{GRPC_SERVER_PORT}")
        print(f"🌐 서버 바인딩: {listen_addr}")
        print("=" * 60)
        print("💡 라즈베리파이에서 C++ 클라이언트 실행:")
        print(f"   ./robot_client {LOCAL_IP}:{GRPC_SERVER_PORT}")
        print("=" * 60)
        print("📈 라즈베리파이로부터의 실시간 로그:")
        print()

        _grpc_server.start()
        print(f"✅ PC gRPC 서버가 포트 {GRPC_SERVER_PORT}에서 실행 중")
        _grpc_server.wait_for_termination()

    except Exception as e:
        print(f"❌ PC gRPC 서버 시작 실패: {e}")
        print("🔧 해결 방법:")
        print(f"   1. 포트 {GRPC_SERVER_PORT}가 사용 중인지 확인")
        print("   2. 방화벽에서 포트 허용")
        print("   3. 관리자 권한으로 실행 시도")

def cleanup_grpc_server():
    """gRPC 서버 정리"""
    global _grpc_server
    if _grpc_server:
        print("🛑 gRPC 서버 종료 중...")
        _grpc_server.stop(grace=2.0)
        _grpc_server = None
        print("✅ gRPC 서버 종료 완료")

# 프로그램 종료 시 정리
atexit.register(cleanup_grpc_server)

def signal_handler(signum, frame):
    """시그널 핸들러"""
    print(f"\n🛑 종료 신호 수신 ({signum})")
    cleanup_grpc_server()
    sys.exit(0)

# 시그널 핸들러 등록
signal.signal(signal.SIGINT, signal_handler)
signal.signal(signal.SIGTERM, signal_handler)

# ── 1) 앱 초기화 ──────────────────────────────────────────────────────────────────────────────────────────────────
app = Dash(__name__,
           external_stylesheets=[dbc.themes.BOOTSTRAP],
           suppress_callback_exceptions=True)

app.title = "Master Device UI"

# ── 2) 공통 헤더 컴포넌트 ──────────────────────────────────────────────────────────────────────────────────────────
header = html.Div(
    style={
        "backgroundColor": "#5A6D8C",
        "padding": "10px 20px",
        "display": "flex",
        "alignItems": "center",
        "justifyContent": "space-between",
        "boxShadow": "0 2px 10px rgba(0,0,0,0.1)"
    },
    children=[
        html.Div([
            html.H1("Master Device",
                    style={
                        "margin": "0",
                        "color": "white",
                        "fontSize": "2.5rem",
                        "fontWeight": "bold",
                        "textShadow": "2px 2px 4px rgba(0,0,0,0.3)"
                    }),
            html.Small("smart teach device",
                       style={"color": "#E8F4FD", "fontSize": "1rem"}),
        ]),
        html.Img(src="/assets/Neuro_Meka.png", style={"height": "50px"}),
    ],
)

# ── 3) dcc.Location + dcc.Store ──────────────────────────────────────────────────────────────────────────────────
app.layout = html.Div([
    dcc.Location(id="url", refresh=False),
    dcc.Store(id="usb-port-store"),
    dcc.Store(id="wifi-conn-store"),
    dcc.Store(id="teleop-state", data={"running": False}),
    html.Div(id="page-content")
])

# ===============================
# 콜백 함수들
# ===============================

# USB 포트 전달 콜백
@app.callback(
    Output("usb-port-store-ui", "data"),
    Input("url", "pathname"),
    State("usb-port-store", "data")
)
def pass_usb_port_to_ui(pathname, port_data):
    """USB 포트 정보를 usb_ui로 전달"""
    if pathname == "/usb-ui" and port_data:
        return port_data
    return None

# ✅ Wi-Fi 연결하기 → /wifi-ui 이동 + 선택값 저장
@app.callback(
    [Output("wifi-conn-store", "data"),
     Output("url", "pathname")],
    Input("btn-wifi-connect", "n_clicks"),
    [State("wifi-ip", "value"),
     State("slave-port", "value"),
     State("master-ip", "value"),
     State("master-port", "value")],
    prevent_initial_call=True
)
def handle_wifi_connect(n_clicks, robot_ip, robot_port, master_ip, master_port):
    if not n_clicks:
        return no_update, no_update

    # 아주 간단한 입력 검증
    if not robot_ip or not robot_port:
        print("❌ Wi-Fi 연결: Robot IP/Port가 비어 있습니다.")
        return no_update, no_update

    try:
        port_int = int(robot_port)
    except Exception:
        print("❌ Wi-Fi 연결: Port가 숫자가 아닙니다.")
        return no_update, no_update

    data = {
        "raspberry_ip": str(robot_ip).strip(),
        "raspberry_port": port_int,
        "master_ip": (str(master_ip).strip() if master_ip else ""),
        "master_port": (int(master_port) if master_port else None),
    }
    print(f"➡️ Wi-Fi 연결 정보 저장: {data}")
    # 저장 후 /wifi-ui 로 라우팅
    return data, "/wifi-ui"

# ✅ wifi_ui에 실제 연결 정보 주입 (Store → Store)
@app.callback(
    Output("raspberry-connection", "data"),
    Input("wifi-conn-store", "data"),
    State("url", "pathname"),
    prevent_initial_call=True
)
def pass_wifi_store_to_wifi_ui(conn_store, pathname):
    if pathname != "/wifi-ui" or not conn_store:
        return no_update
    ip = conn_store.get("raspberry_ip") or conn_store.get("ip")
    port = conn_store.get("raspberry_port") or conn_store.get("port")
    if not ip or not port:
        return no_update
    data = {"ip": ip, "port": int(port)}
    print(f"📦 raspberry-connection 업데이트: {data}")
    return data

# 라우터 콜백
@app.callback(
    Output("page-content", "children"),
    Input("url", "pathname")
)
def display_page(pathname):
    print(f"[DEBUG] Current pathname: {pathname}")
    if pathname == "/usb":
        return usb.layout
    elif pathname == "/usb-ui":
        return usb_ui.layout
    elif pathname == "/wifi":
        return wifi.layout
    elif pathname == "/wifi-ui":
        print("[DEBUG] Loading wifi-ui page")
        return wifi_ui.layout
    elif pathname == "/local":
        return local.layout
    elif pathname == "/local-ui":
        return local_ui.layout
    else:
        # 메인 메뉴
        return html.Div([
            header,

            # 메인 컨테이너
            dbc.Container([
                # 타이틀 섹션
                html.Div([
                    html.H1("Connection Mode 선택",
                            style={
                                'textAlign': 'center',
                                'marginTop': '40px',
                                'marginBottom': '20px',
                                'color': '#2C3E50',
                                'fontWeight': 'bold',
                                'fontSize': '2.5rem'
                            }),
                    html.P("원하는 연결 방식을 선택해주세요",
                           style={
                               'textAlign': 'center',
                               'color': '#7F8C8D',
                               'fontSize': '1.2rem',
                               'marginBottom': '50px'
                           })
                ]),

                # 연결 모드 카드들
                dbc.Row([
                    # Local Connect
                    dbc.Col([
                        html.Div([
                            dcc.Link([
                                html.Div([
                                    html.Div("🖥️",
                                            style={'fontSize': '4rem', 'marginBottom': '20px', 'textAlign': 'center'}),
                                    html.H3("Local Connect",
                                            style={'color': 'white', 'fontWeight': 'bold', 'marginBottom': '15px', 'textAlign': 'center'}),
                                    html.P("로컬 네트워크로 직접 연결",
                                           style={'color': 'rgba(255,255,255,0.9)', 'textAlign': 'center', 'fontSize': '1rem', 'margin': '0'})
                                ])
                            ], href="/local", style={'textDecoration': 'none'})
                        ],
                        style={
                            'background': 'linear-gradient(135deg, #27AE60, #2ECC71)',
                            'borderRadius': '20px', 'padding': '40px 20px', 'textAlign': 'center',
                            'boxShadow': '0 10px 30px rgba(39, 174, 96, 0.3)',
                            'transition': 'all 0.3s ease', 'cursor': 'pointer', 'height': '280px',
                            'display': 'flex', 'alignItems': 'center', 'justifyContent': 'center'
                        })
                    ], width=4),

                    # Wi-Fi Connect
                    dbc.Col([
                        html.Div([
                            dcc.Link([
                                html.Div([
                                    html.Div("📶",
                                            style={'fontSize': '4rem', 'marginBottom': '20px', 'textAlign': 'center'}),
                                    html.H3("Wi-Fi Connect",
                                            style={'color': 'white', 'fontWeight': 'bold', 'marginBottom': '15px', 'textAlign': 'center'}),
                                    html.P("무선 네트워크를 통한 연결",
                                           style={'color': 'rgba(255,255,255,0.9)', 'textAlign': 'center', 'fontSize': '1rem', 'margin': '0'})
                                ])
                            ], href="/wifi", style={'textDecoration': 'none'})
                        ],
                        style={
                            'background': 'linear-gradient(135deg, #3498DB, #5DADE2)',
                            'borderRadius': '20px', 'padding': '40px 20px', 'textAlign': 'center',
                            'boxShadow': '0 10px 30px rgba(52, 152, 219, 0.3)',
                            'transition': 'all 0.3s ease', 'cursor': 'pointer', 'height': '280px',
                            'display': 'flex', 'alignItems': 'center', 'justifyContent': 'center'
                        })
                    ], width=4),

                    # USB Connect
                    dbc.Col([
                        html.Div([
                            dcc.Link([
                                html.Div([
                                    html.Div("🔌",
                                            style={'fontSize': '4rem', 'marginBottom': '20px', 'textAlign': 'center'}),
                                    html.H3("USB Connect",
                                            style={'color': 'white', 'fontWeight': 'bold', 'marginBottom': '15px', 'textAlign': 'center'}),
                                    html.P("USB 시리얼 포트로 직접 연결",
                                           style={'color': 'rgba(255,255,255,0.9)', 'textAlign': 'center', 'fontSize': '1rem', 'margin': '0'})
                                ])
                            ], href="/usb", style={'textDecoration': 'none'})
                        ],
                        style={
                            'background': 'linear-gradient(135deg, #E67E22, #F39C12)',
                            'borderRadius': '20px', 'padding': '40px 20px', 'textAlign': 'center',
                            'boxShadow': '0 10px 30px rgba(230, 126, 34, 0.3)',
                            'transition': 'all 0.3s ease', 'cursor': 'pointer', 'height': '280px',
                            'display': 'flex', 'alignItems': 'center', 'justifyContent': 'center'
                        })
                    ], width=4),
                ], className="g-4", style={'marginBottom': '50px'}),

                # 하단 정보
                html.Div([
                    html.P("💡 각 연결 모드를 클릭하여 마스터 디바이스에 연결하세요",
                           style={'textAlign': 'center', 'color': '#95A5A6', 'fontSize': '1rem', 'marginTop': '30px'})
                ])

            ], fluid=True, style={'minHeight': '80vh'}),
        ])

# ── 서버 실행 (gRPC 서버 자동 시작) ──────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    # PC gRPC 서버 시작 (별도 스레드)
    if GRPC_AVAILABLE:
        print("🤖 PC gRPC 서버를 백그라운드에서 시작합니다...")
        grpc_thread = threading.Thread(target=start_pc_grpc_server, daemon=True)
        grpc_thread.start()
        time.sleep(1)  # 서버 시작 대기
    else:
        print("⚠️ gRPC 모듈이 없어 gRPC 서버를 시작할 수 없습니다.")

    print("=" * 80)
    print("🎉 PC UI 서버 시작 완료!")
    print(f"🌐 웹 인터페이스: http://{LOCAL_IP}:{WEB_SERVER_PORT}")
    print(f"🤖 gRPC 서버: {LOCAL_IP}:{GRPC_SERVER_PORT} (라즈베리파이용)")
    print("=" * 80)
    print("\n🔗 라즈베리파이에서 실행:")
    print(f"   ./robot_client {LOCAL_IP}:{GRPC_SERVER_PORT}")
    print("=" * 80)

    try:
        # Dash 서버 시작 (웹서버)
        app.run(debug=False, host='0.0.0.0', port=WEB_SERVER_PORT)
    except KeyboardInterrupt:
        print("\n🛑 사용자 중단 요청")
    except Exception as e:
        print(f"\n❌ 서버 실행 오류: {e}")
    finally:
        cleanup_grpc_server()
        print("👋 프로그램 종료")