# grpc_data_manager.py - 상호배타적 팔 제어 로직 강화 버전 + save_encoder_pose 메서드 추가
import threading
import time
from typing import Dict, List, Any, Optional
from collections import deque
from dataclasses import dataclass
from datetime import datetime

@dataclass
class GRPCEntry:
    """gRPC 로그 엔트리"""
    timestamp: str
    topic: str
    message: str
    level: str = "INFO"

@dataclass
class EncoderSample:
    """엔코더 샘플 데이터"""
    timestamp: float
    angles: List[float]
    sample_id: int

class GRPCDataManager:
    """
    gRPC 통신 데이터를 관리하는 중앙화된 매니저
    상호배타적 팔 제어 로직 포함
    """
    
    def __init__(self):
        self._lock = threading.RLock()  # 재진입 가능한 락
        
        # 연결 상태
        self._client_info = {}
        self._last_activity = 0.0
        
        # 🔥 상호배타적 팔 제어 상태 (강화된 로직)
        self._gravity_state = {
            "left": {"active": False, "command": "", "timestamp": 0},
            "right": {"active": False, "command": "", "timestamp": 0},
            "last_update": 0,
            "mutex_enforced": True  # 상호배타 강제 활성화
        }
        
        self._position_state = {
            "left": {"active": True, "command": "INIT_ON", "timestamp": time.time()},  # 기본값: Position 활성
            "right": {"active": True, "command": "INIT_ON", "timestamp": time.time()}, # 기본값: Position 활성
            "last_update": time.time(),
            "mutex_enforced": True  # 상호배타 강제 활성화
        }
        
        # 하드웨어 버튼 상태
        self._hardware_buttons = {
            "r_push_1": 1, "l_push_1": 1, "l_push_2": 1,
            "last_update": 0
        }
        
        # 통신 통계
        self._comm_stats = {
            "fps": 0.0, "last_fps_update": 0,
            "total_messages": 0, "error_count": 0
        }
        
        # 녹화 상태
        self._recording_active = False
        self._recording_start_time = None
        self._recording_sample_count = 0
        
        # 데이터 저장소
        self._encoder_data = deque(maxlen=1000)
        self._encoder_samples = deque(maxlen=1000)
        self._current_encoder = []
        self._current_encoder_data = None
        self._saved_poses = []
        self._grpc_log = deque(maxlen=500)
        self._recorded_log = deque(maxlen=1000)
        self._sample_counter = 0
        
        print("[GRPC_DATA_MANAGER] 상호배타적 팔 제어 매니저 초기화 완료")
        print("[GRPC_DATA_MANAGER] 🔄 기본 상태: 양팔 모두 Position Mode 활성")

    # =================
    # 연결 관리
    # =================
    def connect_client(self, client_command: str):
        """클라이언트 연결"""
        with self._lock:
            self._client_info = {
                "command": client_command,
                "connected_at": time.time(),
                "status": "connected"
            }
            self._last_activity = time.time()
            self.add_grpc_entry("CONNECT", f"클라이언트 연결됨: {client_command}")
    
    def disconnect_client(self):
        """클라이언트 연결 해제"""
        with self._lock:
            self._client_info = {"status": "disconnected"}
            self.add_grpc_entry("DISCONNECT", "클라이언트 연결 해제됨")
    
    def is_connected(self) -> bool:
        """연결 상태 확인"""
        with self._lock:
            if not self._client_info.get("status") == "connected":
                return False
            
            # 5초 이상 비활성화되면 연결 끊김으로 간주
            return (time.time() - self._last_activity) < 5.0
    
    def update_activity(self):
        """마지막 활동 시간 업데이트"""
        with self._lock:
            self._last_activity = time.time()

    # =================
    # 🔥 상호배타적 로봇 제어 상태 관리 (핵심 로직)
    # =================
    def set_gravity_mode(self, command: str):
        """
        Gravity 모드 설정 - 상호배타적 로직 적용
        한 팔이 Gravity로 설정되면 다른 팔은 자동으로 Position으로 변경
        """
        with self._lock:
            now = time.time()
            
            print(f"[GRAVITY_MODE] 요청 받음: {command}")
            
            # 명령어 파싱
            if "LEFT" in command.upper():
                target_arm = "left"
                other_arm = "right"
                is_on = "ON" in command.upper()
            elif "RIGHT" in command.upper():
                target_arm = "right"
                other_arm = "left"  
                is_on = "ON" in command.upper()
            elif "ALL" in command.upper():
                # ALL 명령의 경우 양쪽 팔에 동일하게 적용 (하지만 상호배타 위반 가능성 있음)
                is_on = "ON" in command.upper()
                if is_on:
                    # ALL_ON은 허용하지 않음 (상호배타 위배)
                    print(f"[GRAVITY_MODE] ⚠️ ALL_ON 명령 거부 - 상호배타 정책 위배")
                    self.add_grpc_entry("GRAVITY_REJECTED", f"ALL_ON 명령 거부: {command}")
                    return
                else:
                    # ALL_OFF는 허용
                    self._gravity_state["left"]["active"] = False
                    self._gravity_state["right"]["active"] = False
                    self._gravity_state["left"]["command"] = command
                    self._gravity_state["right"]["command"] = command
                    self._gravity_state["last_update"] = now
                    
                    print(f"[GRAVITY_MODE] ✅ 양팔 Gravity OFF 적용")
                    self.add_grpc_entry("GRAVITY", f"양팔 Gravity 모드 해제: {command}")
                    return
            else:
                print(f"[GRAVITY_MODE] ❌ 알 수 없는 명령: {command}")
                return
            
            # 🔥 상호배타 로직 적용
            if is_on:
                # 대상 팔을 Gravity로 설정
                self._gravity_state[target_arm]["active"] = True
                self._gravity_state[target_arm]["command"] = command
                self._gravity_state[target_arm]["timestamp"] = now
                
                # 🔥 다른 팔은 강제로 Gravity OFF (상호배타)
                self._gravity_state[other_arm]["active"] = False
                self._gravity_state[other_arm]["command"] = f"{other_arm.upper()}_OFF_AUTO"
                
                # 🔥 다른 팔을 Position ON으로 설정 (상호배타)
                self._position_state[other_arm]["active"] = True
                self._position_state[other_arm]["command"] = f"{other_arm.upper()}_ON_AUTO"
                
                # 🔥 대상 팔은 Position OFF
                self._position_state[target_arm]["active"] = False
                self._position_state[target_arm]["command"] = f"{target_arm.upper()}_OFF_AUTO"
                
                print(f"[GRAVITY_MODE] 🔥 상호배타 적용: {target_arm} Gravity ON → {other_arm} Position ON")
                self.add_grpc_entry("GRAVITY_MUTEX", f"{target_arm} Gravity ON → {other_arm} Position 자동 전환")
                
            else:
                # 대상 팔 Gravity OFF
                self._gravity_state[target_arm]["active"] = False
                self._gravity_state[target_arm]["command"] = command
                
                # Gravity OFF 시에는 해당 팔을 Position ON으로 설정
                self._position_state[target_arm]["active"] = True
                self._position_state[target_arm]["command"] = f"{target_arm.upper()}_ON_AUTO"
                
                print(f"[GRAVITY_MODE] ✅ {target_arm} Gravity OFF → Position ON 자동 전환")
                self.add_grpc_entry("GRAVITY", f"{target_arm} Gravity OFF → Position 자동 활성화")
            
            self._gravity_state["last_update"] = now
            self._position_state["last_update"] = now

    def set_position_mode(self, command: str):
        """
        Position 모드 설정 - 상호배타적 로직 적용  
        한 팔이 Position으로 설정될 때 특별한 제한은 없지만, Gravity와의 상호배타성은 유지
        """
        with self._lock:
            now = time.time()
            
            print(f"[POSITION_MODE] 요청 받음: {command}")
            
            # 명령어 파싱
            if "LEFT" in command.upper():
                target_arm = "left"
                other_arm = "right"
                is_on = "ON" in command.upper()
            elif "RIGHT" in command.upper():
                target_arm = "right"
                other_arm = "left"
                is_on = "ON" in command.upper()
            elif "ALL" in command.upper():
                is_on = "ON" in command.upper()
                # ALL Position 명령은 허용 (두 팔 모두 Position 가능)
                self._position_state["left"]["active"] = is_on
                self._position_state["right"]["active"] = is_on
                self._position_state["left"]["command"] = command
                self._position_state["right"]["command"] = command
                
                if is_on:
                    # Position ALL_ON 시 Gravity 모두 OFF
                    self._gravity_state["left"]["active"] = False
                    self._gravity_state["right"]["active"] = False
                    print(f"[POSITION_MODE] ✅ 양팔 Position ON → Gravity 모두 OFF")
                
                self._position_state["last_update"] = now
                self.add_grpc_entry("POSITION", f"양팔 Position 모드: {command}")
                return
            else:
                print(f"[POSITION_MODE] ❌ 알 수 없는 명령: {command}")
                return
            
            # 개별 팔 Position 설정
            self._position_state[target_arm]["active"] = is_on
            self._position_state[target_arm]["command"] = command
            self._position_state[target_arm]["timestamp"] = now
            
            if is_on:
                # Position ON 시 해당 팔의 Gravity는 반드시 OFF
                self._gravity_state[target_arm]["active"] = False
                self._gravity_state[target_arm]["command"] = f"{target_arm.upper()}_OFF_AUTO"
                print(f"[POSITION_MODE] ✅ {target_arm} Position ON → Gravity OFF")
                self.add_grpc_entry("POSITION_MUTEX", f"{target_arm} Position ON → Gravity 자동 해제")
            
            self._position_state["last_update"] = now

    def get_robot_state(self) -> Dict[str, Any]:
        """로봇 상태 반환 (상호배타 상태 포함)"""
        with self._lock:
            # 🔥 상호배타성 검증 및 자동 수정
            self._validate_and_fix_mutex_state()
            
            return {
                "connected": self.is_connected(),
                "client_info": self._client_info,
                "gravity": self._gravity_state.copy(),
                "position": self._position_state.copy(),
                "hardware_buttons": self._hardware_buttons.copy(),
                "recording": {
                    "active": self._recording_active,
                    "start_time": self._recording_start_time,
                    "sample_count": self._recording_sample_count
                },
                "communication": self._comm_stats.copy()
            }

    def _validate_and_fix_mutex_state(self):
        """
        🔥 상호배타성 검증 및 자동 수정
        두 팔이 모두 Gravity인 경우 자동으로 수정
        """
        left_grav = self._gravity_state["left"]["active"]
        right_grav = self._gravity_state["right"]["active"]
        
        if left_grav and right_grav:
            # 🚨 상호배타성 위배 감지 - 더 최근에 활성화된 것 유지
            left_time = self._gravity_state["left"].get("timestamp", 0)
            right_time = self._gravity_state["right"].get("timestamp", 0)
            
            if left_time > right_time:
                # 왼팔이 더 최근이므로 오른팔 Gravity OFF
                self._gravity_state["right"]["active"] = False
                self._position_state["right"]["active"] = True
                print("[MUTEX_FIX] 🔧 상호배타성 복구: 오른팔 Gravity OFF → Position ON")
                self.add_grpc_entry("MUTEX_FIX", "상호배타성 위배 자동 수정: 오른팔 Position 복구")
            else:
                # 오른팔이 더 최근이므로 왼팔 Gravity OFF
                self._gravity_state["left"]["active"] = False
                self._position_state["left"]["active"] = True
                print("[MUTEX_FIX] 🔧 상호배타성 복구: 왼팔 Gravity OFF → Position ON")
                self.add_grpc_entry("MUTEX_FIX", "상호배타성 위배 자동 수정: 왼팔 Position 복구")

    # =================
    # 하드웨어 버튼 관리
    # =================
    def update_hardware_buttons(self, r_push_1: int = None, l_push_1: int = None, l_push_2: int = None):
        """하드웨어 버튼 상태 업데이트"""
        with self._lock:
            if r_push_1 is not None:
                self._hardware_buttons["r_push_1"] = r_push_1
            if l_push_1 is not None:
                self._hardware_buttons["l_push_1"] = l_push_1
            if l_push_2 is not None:
                self._hardware_buttons["l_push_2"] = l_push_2
            self._hardware_buttons["last_update"] = time.time()
            self.update_activity()

    def get_hardware_buttons(self) -> Dict[str, Any]:
        """하드웨어 버튼 상태 반환"""
        with self._lock:
            return self._hardware_buttons.copy()

    # =================
    # 엔코더 데이터 관리
    # =================
    def update_encoder_data(self, angles: List[float]):
        """실시간 엔코더 데이터 업데이트"""
        with self._lock:
            self._current_encoder = angles.copy()
            self._sample_counter += 1
            
            # EncoderSample 객체 생성
            now = time.time()
            sample = EncoderSample(
                timestamp=now,
                angles=angles.copy(),
                sample_id=self._sample_counter
            )
            
            self._current_encoder_data = sample
            self._encoder_samples.append(sample)
            
            # 기존 호환성을 위한 데이터도 저장
            self._encoder_data.append({
                "timestamp": now,
                "angles": angles.copy()
            })
            
            # 녹화 중이면 로그에 추가
            if self._recording_active:
                self.add_recorded_entry(f"Sample #{self._sample_counter}: {len(angles)}개 관절")
            
            self.update_activity()
            
            # 통신 통계 업데이트
            self._comm_stats["total_messages"] += 1
            
            # FPS 계산
            if self._comm_stats["last_fps_update"] == 0:
                self._comm_stats["last_fps_update"] = now
            elif now - self._comm_stats["last_fps_update"] >= 1.0:
                # 1초마다 FPS 재계산
                recent_count = sum(1 for entry in self._encoder_data 
                                 if entry["timestamp"] > now - 1.0)
                self._comm_stats["fps"] = recent_count
                self._comm_stats["last_fps_update"] = now

    def get_current_encoder_data(self) -> Optional[Dict[str, Any]]:
        """현재 엔코더 데이터 반환 (UI 호환성을 위해 Dict 형태로)"""
        with self._lock:
            if not self._current_encoder_data:
                return None
            
            # 밀리초 포함 타임스탬프 생성
            timestamp_str = time.strftime("%H:%M:%S", time.localtime(self._current_encoder_data.timestamp))
            microseconds = int((self._current_encoder_data.timestamp % 1) * 1000)
            timestamp_with_ms = f"{timestamp_str}.{microseconds:03d}"
            
            return {
                "timestamp": timestamp_with_ms,
                "angles": self._current_encoder_data.angles,
                "sample_id": self._current_encoder_data.sample_id
            }

    # =================
    # 포즈 관리 (누락된 메서드들 추가)
    # =================
    def save_encoder_pose(self, angles: List[float], name: str = None) -> str:
        """
        엔코더 각도로 포즈 저장 (누락된 메서드 추가)
        """
        with self._lock:
            if name is None:
                name = f"Pose_{len(self._saved_poses) + 1:03d}"
            
            pose = {
                "name": name,
                "angles": angles.copy(),
                "timestamp": datetime.now().strftime("%H:%M:%S"),
                "saved_at": time.time()
            }
            
            self._saved_poses.append(pose)
            self.add_grpc_entry("SAVE_POSE", f"포즈 저장: {name} ({len(angles)}개 관절)")
            self.add_recorded_entry(f"💾 포즈 저장: {name}")
            
            print(f"[SAVE_ENCODER_POSE] ✅ {name} 저장 완료: {len(angles)}개 관절")
            return name

    def save_pose(self, name: str = None) -> str:
        """현재 포즈 저장 (기존 메서드)"""
        with self._lock:
            if not self._current_encoder:
                return "저장할 엔코더 데이터가 없습니다"
            
            return self.save_encoder_pose(self._current_encoder, name)

    def get_saved_poses(self) -> List[Dict]:
        """저장된 포즈 목록 반환"""
        with self._lock:
            return self._saved_poses.copy()

    def clear_poses(self):
        """저장된 포즈 모두 삭제"""
        with self._lock:
            pose_count = len(self._saved_poses)
            self._saved_poses.clear()
            self.add_grpc_entry("CLEAR_POSES", f"{pose_count}개 포즈 삭제됨")
            self.add_recorded_entry(f"🗑️ 모든 포즈 삭제됨 ({pose_count}개)")
            print(f"[CLEAR_POSES] ✅ {pose_count}개 포즈 삭제 완료")

    def delete_pose_by_name(self, pose_name: str) -> bool:
        """특정 포즈 삭제"""
        with self._lock:
            for i, pose in enumerate(self._saved_poses):
                if pose["name"] == pose_name:
                    del self._saved_poses[i]
                    self.add_grpc_entry("DELETE_POSE", f"포즈 삭제: {pose_name}")
                    self.add_recorded_entry(f"🗑️ 포즈 삭제: {pose_name}")
                    print(f"[DELETE_POSE] ✅ 포즈 '{pose_name}' 삭제 완료")
                    return True
            
            print(f"[DELETE_POSE] ❌ 포즈 '{pose_name}'을 찾을 수 없음")
            return False

    def delete_recorded_data(self):
        """녹화된 데이터 삭제"""
        with self._lock:
            log_count = len(self._recorded_log)
            encoder_count = len(self._encoder_data)
            
            self._recorded_log.clear()
            self._encoder_data.clear()
            self._encoder_samples.clear()
            self._current_encoder = []
            self._current_encoder_data = None
            self._sample_counter = 0
            
            self.add_grpc_entry("DELETE_RECORDED", f"녹화 데이터 삭제: 로그 {log_count}개, 샘플 {encoder_count}개")
            print(f"[DELETE_RECORDED] ✅ 녹화 데이터 삭제 완료: 로그 {log_count}개, 샘플 {encoder_count}개")

    # =================
    # gRPC 로그 관리
    # =================
    def add_grpc_entry(self, topic: str, message: str, level: str = "INFO"):
        """gRPC 로그 엔트리 추가"""
        with self._lock:
            entry = GRPCEntry(
                timestamp=time.strftime("%H:%M:%S"),
                topic=topic,
                message=message,
                level=level
            )
            self._grpc_log.append(entry)

    def get_grpc_entries(self, limit: int = 50) -> List[Dict]:
        """gRPC 로그 엔트리 반환"""
        with self._lock:
            entries = list(self._grpc_log)[-limit:] if limit else list(self._grpc_log)
            return [
                {
                    "timestamp": entry.timestamp,
                    "topic": entry.topic,
                    "message": entry.message,
                    "level": entry.level
                }
                for entry in reversed(entries)
            ]

    def get_encoder_entries(self, limit: int = 10) -> List[Dict]:
        """엔코더 데이터 엔트리 반환"""
        with self._lock:
            samples = list(self._encoder_samples)[-limit:]
            entries = []
            
            for sample in reversed(samples):
                # timestamp 포맷팅
                timestamp_str = time.strftime("%H:%M:%S", time.localtime(sample.timestamp))
                microseconds = int((sample.timestamp % 1) * 1000)
                timestamp_with_ms = f"{timestamp_str}.{microseconds:03d}"
                
                entries.append({
                    "timestamp": timestamp_with_ms,
                    "angles": sample.angles[:6] if len(sample.angles) >= 6 else sample.angles,
                    "sample_id": sample.sample_id
                })
            
            return entries

    # =================
    # 녹화 관리
    # =================
    def start_recording(self):
        """녹화 시작"""
        with self._lock:
            self._recording_active = True
            self._recording_start_time = time.time()
            self._recording_sample_count = 0
            self.add_grpc_entry("RECORDING", "녹화 시작")
            self.add_recorded_entry("🔹 녹화 시작")

    def stop_recording(self) -> Optional[str]:
        """녹화 중지 및 포즈 저장"""
        with self._lock:
            if not self._recording_active:
                return None
            
            self._recording_active = False
            
            # 현재 엔코더 데이터를 포즈로 저장
            if self._current_encoder_data:
                pose_name = self.save_encoder_pose(self._current_encoder_data.angles)
                duration = time.time() - self._recording_start_time
                
                self.add_grpc_entry("RECORDING", f"녹화 완료: {pose_name} ({self._recording_sample_count}샘플, {duration:.1f}초)")
                self.add_recorded_entry(f"💾 녹화 완료: {pose_name}")
                return pose_name
            
            return None

    def is_recording(self) -> bool:
        """녹화 상태 확인"""
        with self._lock:
            return self._recording_active

    def add_recorded_entry(self, message: str):
        """녹화 로그 엔트리 추가"""
        with self._lock:
            timestamp = time.strftime("%H:%M:%S")
            self._recorded_log.append(f"[{timestamp}] {message}")
            if self._recording_active:
                self._recording_sample_count += 1

    def get_recorded_log(self, limit: int = 100) -> List[str]:
        """녹화 로그 반환"""
        with self._lock:
            return list(self._recorded_log)[-limit:]

    # =================
    # 통계 및 상태
    # =================
    def get_statistics(self) -> Dict[str, Any]:
        """전체 통계 정보 반환"""
        with self._lock:
            return {
                "connected": self.is_connected(),
                "current_fps": self._comm_stats["fps"],
                "total_samples": len(self._encoder_data),
                "saved_poses": len(self._saved_poses),
                "grpc_logs": len(self._grpc_log),
                "recording_active": self._recording_active,
                "recording_samples": self._recording_sample_count,
                "uptime": time.time() - (self._client_info.get("connected_at", time.time())),
                "mutex_enforced": self._gravity_state.get("mutex_enforced", True)
            }

    def reset_all_data(self):
        """모든 데이터 초기화 (연결 상태 제외)"""
        with self._lock:
            # 데이터 카운트 저장
            encoder_count = len(self._encoder_data)
            pose_count = len(self._saved_poses)
            log_count = len(self._recorded_log)
            
            # 데이터 초기화
            self._encoder_data.clear()
            self._encoder_samples.clear()
            self._saved_poses.clear()
            self._recorded_log.clear()
            self._current_encoder = []
            self._current_encoder_data = None
            self._recording_active = False
            self._recording_sample_count = 0
            self._sample_counter = 0
            self._comm_stats.update({"fps": 0.0, "total_messages": 0, "error_count": 0})
            
            # 🔥 로봇 상태는 안전한 기본값으로 초기화 (상호배타성 유지)
            self._gravity_state = {
                "left": {"active": False, "command": "RESET", "timestamp": time.time()},
                "right": {"active": False, "command": "RESET", "timestamp": time.time()},
                "last_update": time.time(),
                "mutex_enforced": True
            }
            self._position_state = {
                "left": {"active": True, "command": "RESET_ON", "timestamp": time.time()},
                "right": {"active": True, "command": "RESET_ON", "timestamp": time.time()},
                "last_update": time.time(),
                "mutex_enforced": True
            }
            
            self.add_grpc_entry("RESET", f"모든 데이터 초기화: 엔코더 {encoder_count}개, 포즈 {pose_count}개, 로그 {log_count}개 삭제")
            self.add_recorded_entry("🔄 시스템 초기화 - 양팔 Position 모드로 복귀")

# 전역 인스턴스 (싱글톤)
grpc_data_manager = GRPCDataManager()