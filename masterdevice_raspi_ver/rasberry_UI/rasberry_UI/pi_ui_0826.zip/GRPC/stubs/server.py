# GRPC/stubs/server.py

import time
from concurrent import futures
import grpc
import threading
import sys
from pathlib import Path

# ✅ 패키지/상대 임포트로 고정 (둘 다 지원)
try:
    # 패키지로 실행: python -m GRPC.stubs.server 또는 다른 파일에서 import
    from . import masterdevice_pb2 as pb2
    from . import masterdevice_pb2_grpc as pb2_grpc
except ImportError:
    # 파일 단독 실행: python GRPC/stubs/server.py
    sys.path.append(str(Path(__file__).resolve().parent))
    import masterdevice_pb2 as pb2
    import masterdevice_pb2_grpc as pb2_grpc

# grpc_data_manager import 시도
try:
    # 상위 디렉토리에서 import
    sys.path.append(str(Path(__file__).resolve().parent.parent.parent))
    from grpc_data_manager import grpc_data_manager
    DATA_MANAGER_AVAILABLE = True
except ImportError as e:
    print(f"[WARNING] grpc_data_manager import 실패: {e}")
    DATA_MANAGER_AVAILABLE = False
    grpc_data_manager = None


class MasterDeviceServer(pb2_grpc.masterdeviceServicer):
    """개선된 masterdevice gRPC 서비스 서버"""
    
    def __init__(self, enable_data_manager: bool = True):
        self.req_id = 0
        self.enable_data_manager = enable_data_manager and DATA_MANAGER_AVAILABLE
        self.server_start_time = time.time()
        self.client_connections = {}  # 클라이언트별 연결 정보
        
        print("✅ MasterDevice gRPC 서비스 준비 완료")
        if self.enable_data_manager:
            print("📊 Data Manager 연동 활성화")
        else:
            print("⚠️ Data Manager 연동 비활성화")

    def _log(self, rpc_name: str, payload: str, context):
        """통합 로깅 함수"""
        self.req_id += 1
        peer = context.peer() if context else "unknown"
        client_ip = self._extract_client_ip(peer)
        timestamp = time.strftime("%H:%M:%S")
        
        # 콘솔 로그
        print(f"[{timestamp}] 🔥 #{self.req_id} {rpc_name} from {client_ip}")
        print(f"       └ payload: {payload}")
        
        # 데이터 매니저 로깅
        if self.enable_data_manager:
            log_message = f"[{rpc_name}] {payload} (from {client_ip})"
            grpc_data_manager.add_grpc_entry("RECEIVED", log_message)
        
        # 클라이언트 연결 추적
        self.client_connections[client_ip] = {
            "last_seen": time.time(),
            "request_count": self.client_connections.get(client_ip, {}).get("request_count", 0) + 1,
            "last_rpc": rpc_name
        }

    def _extract_client_ip(self, peer_str: str) -> str:
        """peer 문자열에서 클라이언트 IP 추출"""
        try:
            # gRPC peer format: "ipv4:192.168.0.43:12345" 또는 "unix:/path"
            if "ipv4:" in peer_str:
                parts = peer_str.split(':')
                return parts[1] if len(parts) >= 2 else "unknown"
            elif ":" in peer_str:
                return peer_str.split(':')[-2]  # 마지막에서 두 번째 (IP 부분)
            else:
                return peer_str
        except:
            return "unknown"

    def _safe_execute(self, operation_name: str, operation_func):
        """안전한 실행 래퍼 (예외 처리)"""
        try:
            return operation_func()
        except Exception as e:
            error_msg = f"{operation_name} 실행 오류: {str(e)}"
            print(f"    ❌ {error_msg}")
            if self.enable_data_manager:
                grpc_data_manager.add_grpc_entry("ERROR", error_msg)
            return None

    # =================
    # gRPC 서비스 메서드들
    # =================

    def Connect(self, request, context):
        """연결 요청 처리"""
        self._log("Connect", request.command, context)
        
        def connect_operation():
            if self.enable_data_manager:
                grpc_data_manager.connect_client(request.command)
            
            response_msg = f"연결 성공: {request.command}"
            print(f"    ✅ 클라이언트 연결 완료")
            return pb2.ConnectMessage(message=response_msg)
        
        result = self._safe_execute("Connect", connect_operation)
        return result or pb2.ConnectMessage(message="연결 실패")

    def GravityMode(self, request, context):
        """Gravity 모드 처리 - 라즈베리파이로부터 상태 수신"""
        self._log("GravityMode", request.command, context)
        
        def gravity_operation():
            if self.enable_data_manager:
                grpc_data_manager.set_gravity_mode(request.command)
                # ✅ 상호배타 보장: Gravity ON 켜지면 Position은 끄기
                if "ON" in request.command.upper():
                    grpc_data_manager.set_position_mode("ALL_OFF")
                    grpc_data_manager.add_grpc_entry("MUTEX", f"Gravity {request.command} → Position ALL_OFF")
            
            print(f"    🌍 Gravity 모드 업데이트: {request.command}")
            return pb2.GravityReply(message=f"Gravity 설정 완료: {request.command}")
        
        result = self._safe_execute("GravityMode", gravity_operation)
        return result or pb2.GravityReply(message="Gravity 설정 실패")

    def PositionMode(self, request, context):
        """Position 모드 처리 - 라즈베리파이로부터 상태 수신"""
        self._log("PositionMode", request.command, context)
        
        def position_operation():
            if self.enable_data_manager:
                grpc_data_manager.set_position_mode(request.command)
                # ✅ 상호배타 보장: Position ON 켜지면 Gravity는 끄기
                if "ON" in request.command.upper():
                    grpc_data_manager.set_gravity_mode("ALL_OFF")
                    grpc_data_manager.add_grpc_entry("MUTEX", f"Position {request.command} → Gravity ALL_OFF")
            
            print(f"    📍 Position 모드 업데이트: {request.command}")
            return pb2.PositionReply(message=f"Position 설정 완료: {request.command}")
        
        result = self._safe_execute("PositionMode", position_operation)
        return result or pb2.PositionReply(message="Position 설정 실패")

    def Save(self, request_iterator, context):
        """Save 처리 - client-streaming 방식 (올바른 proto에 맞춤)"""
        client_addr = context.peer()
        self._log("Save", "stream start", client_addr)

        total_msgs = 0
        last_action = "NONE"

        try:
            for req in request_iterator:
                total_msgs += 1
                cmd = getattr(req, "command", "") or ""
                has_angles = len(getattr(req, "angle", [])) > 0

                if cmd == "SAVE_START":
                    if self.enable_data_manager:
                        grpc_data_manager.start_recording()
                    last_action = "SAVE_START"
                    grpc_data_manager.add_grpc_entry("SAVE", "녹화 시작")
                    print("    🔹 SAVE_START")
                elif cmd == "SAVE_STOP":
                    if self.enable_data_manager:
                        pose_name = grpc_data_manager.stop_recording()
                        last_action = f"SAVE_STOP:{pose_name}"
                        grpc_data_manager.add_grpc_entry("SAVE", f"녹화 종료: {pose_name}")
                    print(f"    💾 SAVE_STOP → {pose_name if self.enable_data_manager else 'N/A'}")
                elif has_angles:
                    angles = list(req.angle)
                    if self.enable_data_manager:
                        pose_name = grpc_data_manager.save_encoder_pose(angles)
                        last_action = f"SAVE_ANGLES:{pose_name}"
                        grpc_data_manager.add_grpc_entry("SAVE", f"각도 저장: {pose_name} ({len(angles)}개)")
                    print(f"    💾 각도 저장 완료: {pose_name if self.enable_data_manager else 'N/A'}")
                else:
                    if self.enable_data_manager:
                        grpc_data_manager.add_grpc_entry("SAVE", f"알 수 없는 메시지 #{total_msgs}")

            # 스트림 종료
            print(f"    ✅ Save stream end, total msgs={total_msgs}, last={last_action}")
            return pb2.SaveReply()  # message 필드 없음
        except Exception as e:
            print(f"    ❌ Save 스트림 처리 오류: {e}")
            if self.enable_data_manager:
                grpc_data_manager.add_grpc_entry("ERROR", f"Save 스트림 오류: {str(e)}")
            return pb2.SaveReply()

    def Homing(self, request, context):
        """홈 이동 처리"""
        self._log("Homing", request.command, context)
        
        def homing_operation():
            message = ""
            if request.command == "GO_HOME":
                message = "홈 위치로 이동 완료"
                print(f"    🏠 홈 이동 실행")
            else:
                message = f"홈 관련 명령 처리: {request.command}"
                print(f"    🏠 홈 명령: {request.command}")
            
            if self.enable_data_manager:
                grpc_data_manager.add_grpc_entry("HOMING", message)
            
            return pb2.HomingReply(message=message)
        
        result = self._safe_execute("Homing", homing_operation)
        return result or pb2.HomingReply(message="홈 이동 실패")

    def Teleoperation1(self, request, context):
        """텔레오퍼레이션 단발 명령 처리"""
        self._log("Teleoperation1", request.command, context)
        
        def teleop1_operation():
            message = ""
            if request.command == "START":
                message = "텔레오퍼레이션 시작"
                print(f"    🎮 텔레오퍼레이션 시작")
            elif request.command == "STOP":
                message = "텔레오퍼레이션 중지"
                print(f"    ⹂ 텔레오퍼레이션 중지")
            else:
                message = f"텔레오퍼레이션 명령 처리: {request.command}"
                print(f"    🎮 텔레오퍼레이션: {request.command}")
            
            if self.enable_data_manager:
                grpc_data_manager.add_grpc_entry("TELEOP", message)
            
            return pb2.TeleoperationMessage1(message=message)
        
        result = self._safe_execute("Teleoperation1", teleop1_operation)
        return result or pb2.TeleoperationMessage1(message="텔레오퍼레이션 실패")

    def Teleoperation2(self, request_iterator, context):
        """텔레오퍼레이션 스트림 처리 (10Hz 엔코더 데이터)"""
        client_ip = self._extract_client_ip(context.peer())
        self._log("Teleoperation2", "스트림 시작", context)
        
        def teleop2_stream_operation():
            count = 0
            start_time = time.time()
            last_log_time = start_time
            
            try:
                for request in request_iterator:
                    count += 1
                    angles = list(request.angle)
                    
                    # 데이터 매니저에 실시간 업데이트
                    if self.enable_data_manager:
                        grpc_data_manager.update_encoder_data(angles)
                    
                    # 주기적 로그 (1초마다 또는 50샘플마다) - 10Hz이므로 50샘플 = 5초
                    current_time = time.time()
                    if (current_time - last_log_time) >= 2.0 or count % 20 == 0:  # 2초마다 또는 20샘플마다
                        elapsed = current_time - start_time
                        fps = count / elapsed if elapsed > 0 else 0
                        print(f"    🎮 스트림 데이터: {count}개, {fps:.1f} FPS, {len(angles)}축")
                        last_log_time = current_time
                
                # 스트림 완료 통계
                total_time = time.time() - start_time
                final_fps = count / total_time if total_time > 0 else 0
                message = f"스트림 완료: {count}개, {final_fps:.1f} FPS, {total_time:.1f}초"
                
                print(f"    ✅ {message}")
                
                if self.enable_data_manager:
                    grpc_data_manager.add_grpc_entry("TELEOP_STREAM", message)
                
                return pb2.TeleoperationMessage2(message=message)
                
            except Exception as e:
                error_msg = f"스트림 처리 오류: {str(e)}"
                print(f"    ❌ {error_msg}")
                if self.enable_data_manager:
                    grpc_data_manager.add_grpc_entry("ERROR", error_msg)
                return pb2.TeleoperationMessage2(message=error_msg)
        
        return self._safe_execute("Teleoperation2", teleop2_stream_operation) or pb2.TeleoperationMessage2(message="스트림 실패")

    def Delete(self, request, context):
        """삭제 명령 처리"""
        self._log("Delete", request.command, context)
        
        def delete_operation():
            if "POSE" in request.command.upper():
                if self.enable_data_manager:
                    grpc_data_manager.clear_poses()
                print(f"    🗑️ 포즈 데이터 삭제")
            elif "ALL" in request.command.upper():
                if self.enable_data_manager:
                    grpc_data_manager.reset_all_data()
                print(f"    🗑️ 모든 데이터 삭제")
            else:
                print(f"    🗑️ 삭제 명령: {request.command}")
            
            if self.enable_data_manager:
                grpc_data_manager.add_grpc_entry("DELETE", request.command)
            
            return pb2.DeleteReply()  # message 필드 없음
        
        result = self._safe_execute("Delete", delete_operation)
        return result or pb2.DeleteReply()

    def PowerOff(self, request, context):
        """전원 종료 처리"""
        self._log("PowerOff", request.command, context)
        
        def poweroff_operation():
            message = ""
            if request.command == "POWER_OFF":
                message = "시스템 종료 신호 처리됨"
                print(f"    🔌 시스템 전원 종료 신호")
                if self.enable_data_manager:
                    grpc_data_manager.disconnect_client()
            else:
                message = f"전원 관리 처리됨: {request.command}"
                print(f"    🔌 전원 명령: {request.command}")
            
            if self.enable_data_manager:
                grpc_data_manager.add_grpc_entry("POWER", message)
            
            return pb2.PowerOffReply(message=message)
        
        result = self._safe_execute("PowerOff", poweroff_operation)
        return result or pb2.PowerOffReply(message="전원 관리 실패")

    # =================
    # 서버 상태 정보
    # =================
    
    def get_server_stats(self) -> dict:
        """서버 통계 정보 반환"""
        uptime = time.time() - self.server_start_time
        active_clients = len([c for c in self.client_connections.values() 
                            if (time.time() - c["last_seen"]) < 30])
        
        return {
            "total_requests": self.req_id,
            "uptime_seconds": uptime,
            "active_clients": active_clients,
            "total_clients": len(self.client_connections),
            "data_manager_enabled": self.enable_data_manager
        }

    def print_server_stats(self):
        """서버 통계 출력"""
        stats = self.get_server_stats()
        print("\n📊 서버 통계:")
        print(f"   총 요청 수: {stats['total_requests']}")
        print(f"   가동 시간: {stats['uptime_seconds']:.1f}초")
        print(f"   활성 클라이언트: {stats['active_clients']}")
        print(f"   총 클라이언트: {stats['total_clients']}")
        print(f"   Data Manager: {'활성화' if stats['data_manager_enabled'] else '비활성화'}")


def serve(host: str = "0.0.0.0", port: int = 50052, max_workers: int = 10):
    """gRPC 서버 시작"""
    
    # 서버 생성
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=max_workers))
    service_impl = MasterDeviceServer(enable_data_manager=DATA_MANAGER_AVAILABLE)
    
    # 서비스 등록
    pb2_grpc.add_masterdeviceServicer_to_server(service_impl, server)
    
    # 포트 바인딩
    bind_addr = f"{host}:{port}"
    server.add_insecure_port(bind_addr)

    print("=" * 70)
    print("🚀 MasterDevice gRPC 서버 (라즈베리파이 → PC)")
    print("=" * 70)
    print(f"📡 바인딩: {bind_addr}")
    print(f"👥 최대 워커: {max_workers}")
    print(f"📊 데이터 매니저: {'활성화' if DATA_MANAGER_AVAILABLE else '비활성화'}")
    print(f"💡 라즈베리파이 접속 주소: 192.168.0.4:{port}")
    print("=" * 70)
    print("📋 지원 RPC:")
    print("   • Connect - 연결 관리")
    print("   • GravityMode - Gravity 제어 상태")
    print("   • PositionMode - Position 제어 상태")
    print("   • Save - 포즈 저장 & 녹화 제어")
    print("   • Teleoperation1 - 텔레오퍼레이션 명령")
    print("   • Teleoperation2 - 실시간 엔코더 스트림 (10Hz)")
    print("   • Homing - 홈 이동")
    print("   • Delete - 데이터 삭제")
    print("   • PowerOff - 전원 관리")
    print("=" * 70)

    server.start()
    print("✅ 서버 시작 완료. 요청 대기 중...")
    
    try:
        while True:
            time.sleep(5)
            # 주기적으로 서버 통계 출력 (선택적)
            # service_impl.print_server_stats()
    except KeyboardInterrupt:
        print("\n🛑 종료 신호 수신. 서버 정리 중...")
        server.stop(grace=3.0)
        print("👋 서버 종료 완료.")
    except Exception as e:
        print(f"\n❌ 서버 오류: {e}")
        server.stop(grace=1.0)


def serve_async(host: str = "0.0.0.0", port: int = 50052, max_workers: int = 10):
    """비동기 서버 시작 (다른 스레드에서 호출용)"""
    def run_server():
        serve(host, port, max_workers)
    
    thread = threading.Thread(target=run_server, daemon=True)
    thread.start()
    return thread


if __name__ == "__main__":
    # 기본 설정으로 서버 시작
    serve()