# GRPC/stubs/client.py
import grpc
import time
import sys
from pathlib import Path

# ✅ 절대 임포트 경로 고정
try:
    # 패키지 형태로 import
    from . import masterdevice_pb2
    from . import masterdevice_pb2_grpc
except ImportError:
    # 직접 실행시나 경로 문제시 대체 import
    sys.path.append(str(Path(__file__).resolve().parent))
    import masterdevice_pb2
    import masterdevice_pb2_grpc

# ===============================
# 설정 및 상수
# ===============================
DEFAULT_TIMEOUT = 5.0  # 기본 타임아웃 (초)
MAX_RETRIES = 3        # 최대 재시도 횟수

# ===============================
# 유틸리티 함수
# ===============================
def create_channel_with_timeout(ip: str, port: int, timeout: float = DEFAULT_TIMEOUT):
    """타임아웃을 적용한 gRPC 채널 생성"""
    channel_address = f"{ip}:{port}"
    
    # 채널 옵션 설정
    options = [
        ('grpc.keepalive_time_ms', 10000),        # 10초마다 keepalive
        ('grpc.keepalive_timeout_ms', 3000),      # keepalive 타임아웃 3초
        ('grpc.keepalive_permit_without_calls', True),
        ('grpc.http2.max_pings_without_data', 0),
        ('grpc.http2.min_time_between_pings_ms', 5000),
        ('grpc.http2.min_ping_interval_without_data_ms', 10000)
    ]
    
    return grpc.insecure_channel(channel_address, options=options)

def safe_grpc_call(operation_name: str, grpc_call_func, retries: int = MAX_RETRIES):
    """안전한 gRPC 호출 래퍼 (재시도 및 예외 처리)"""
    for attempt in range(retries):
        try:
            result = grpc_call_func()
            print(f"[DEBUG] {operation_name} 성공 (시도 {attempt + 1}/{retries})")
            return result
        except grpc.RpcError as e:
            error_code = e.code()
            error_details = e.details()
            print(f"[ERROR] {operation_name} gRPC 오류 (시도 {attempt + 1}/{retries}): {error_code} - {error_details}")
            
            if attempt == retries - 1:  # 마지막 시도
                raise Exception(f"{operation_name} 실패: {error_code} - {error_details}")
            
            # 잠시 대기 후 재시도
            time.sleep(0.5 * (attempt + 1))
        except Exception as e:
            print(f"[ERROR] {operation_name} 일반 오류 (시도 {attempt + 1}/{retries}): {str(e)}")
            
            if attempt == retries - 1:  # 마지막 시도
                raise Exception(f"{operation_name} 실패: {str(e)}")
            
            # 잠시 대기 후 재시도
            time.sleep(0.5 * (attempt + 1))

# ===============================
# gRPC 클라이언트 함수들 (UI → 라즈베리파이)
# ===============================

def send_connect_command(ip: str, port: int, command: str) -> str:
    """연결 명령 전송"""
    def grpc_operation():
        with create_channel_with_timeout(ip, port) as channel:
            stub = masterdevice_pb2_grpc.masterdeviceStub(channel)
            request = masterdevice_pb2.ConnectCommand(command=command)
            
            # 타임아웃 설정하여 호출
            response = stub.Connect(request, timeout=DEFAULT_TIMEOUT)
            return response.message.strip()
    
    try:
        result = safe_grpc_call("Connect", grpc_operation)
        print(f"[CLIENT] Connect 응답: {result}")
        return result
    except Exception as e:
        error_msg = f"연결 실패: {str(e)}"
        print(f"[CLIENT] {error_msg}")
        return error_msg

def send_homing_command(ip: str, port: int, command: str) -> str:
    """홈 이동 명령 전송"""
    def grpc_operation():
        with create_channel_with_timeout(ip, port) as channel:
            stub = masterdevice_pb2_grpc.masterdeviceStub(channel)
            request = masterdevice_pb2.HomingCommand(command=command)
            
            response = stub.Homing(request, timeout=DEFAULT_TIMEOUT)
            return response.message.strip()
    
    try:
        result = safe_grpc_call("Homing", grpc_operation)
        print(f"[CLIENT] Homing 응답: {result}")
        return result
    except Exception as e:
        error_msg = f"홈 이동 실패: {str(e)}"
        print(f"[CLIENT] {error_msg}")
        return error_msg

def send_master_teleop_command(ip: str, port: int, command: str) -> str:
    """마스터 텔레오퍼레이션 명령 전송"""
    def grpc_operation():
        with create_channel_with_timeout(ip, port) as channel:
            stub = masterdevice_pb2_grpc.masterdeviceStub(channel)
            request = masterdevice_pb2.TeleoperationCommand1(command=command)
            
            response = stub.Teleoperation1(request, timeout=DEFAULT_TIMEOUT)
            return response.message.strip()
    
    try:
        result = safe_grpc_call("Teleoperation", grpc_operation)
        print(f"[CLIENT] Teleop 응답: {result}")
        return result
    except Exception as e:
        error_msg = f"텔레오퍼레이션 실패: {str(e)}"
        print(f"[CLIENT] {error_msg}")
        return error_msg

def send_gravity_mode_command(ip: str, port: int, command: str) -> str:
    """Gravity 모드 명령 전송"""
    def grpc_operation():
        with create_channel_with_timeout(ip, port) as channel:
            stub = masterdevice_pb2_grpc.masterdeviceStub(channel)
            request = masterdevice_pb2.GravityState(command=command)
            
            response = stub.GravityMode(request, timeout=DEFAULT_TIMEOUT)
            return "Gravity 모드 설정 완료"
    
    try:
        result = safe_grpc_call("GravityMode", grpc_operation)
        print(f"[CLIENT] Gravity 모드 설정: {command}")
        return result
    except Exception as e:
        error_msg = f"Gravity 모드 설정 실패: {str(e)}"
        print(f"[CLIENT] {error_msg}")
        return error_msg

def send_position_mode_command(ip: str, port: int, command: str) -> str:
    """Position 모드 명령 전송"""
    def grpc_operation():
        with create_channel_with_timeout(ip, port) as channel:
            stub = masterdevice_pb2_grpc.masterdeviceStub(channel)
            request = masterdevice_pb2.PositionState(command=command)
            
            response = stub.PositionMode(request, timeout=DEFAULT_TIMEOUT)
            return "Position 모드 설정 완료"
    
    try:
        result = safe_grpc_call("PositionMode", grpc_operation)
        print(f"[CLIENT] Position 모드 설정: {command}")
        return result
    except Exception as e:
        error_msg = f"Position 모드 설정 실패: {str(e)}"
        print(f"[CLIENT] {error_msg}")
        return error_msg

def send_save_command(ip: str, port: int, angles: list = None, command: str = None) -> str:
    """포즈 저장 명령 전송"""
    def grpc_operation():
        with create_channel_with_timeout(ip, port) as channel:
            stub = masterdevice_pb2_grpc.masterdeviceStub(channel)
            
            if command:
                # 명령어 기반 저장 (SAVE_START/SAVE_STOP)
                request = masterdevice_pb2.SaveCommand(command=command)
            elif angles:
                # 각도 배열 기반 저장
                request = masterdevice_pb2.SaveCommand(angle=angles)
            else:
                raise ValueError("command 또는 angles 중 하나는 반드시 제공되어야 합니다")
            
            response = stub.Save(request, timeout=DEFAULT_TIMEOUT)
            return "포즈 저장 완료"
    
    try:
        operation_desc = f"Save({command if command else f'{len(angles)}개 관절'})"
        result = safe_grpc_call(operation_desc, grpc_operation)
        print(f"[CLIENT] 포즈 저장 완료")
        return result
    except Exception as e:
        error_msg = f"포즈 저장 실패: {str(e)}"
        print(f"[CLIENT] {error_msg}")
        return error_msg

def send_delete_command(ip: str, port: int, command: str) -> str:
    """삭제 명령 전송"""
    def grpc_operation():
        with create_channel_with_timeout(ip, port) as channel:
            stub = masterdevice_pb2_grpc.masterdeviceStub(channel)
            request = masterdevice_pb2.DeleteCommand(command=command)
            
            response = stub.Delete(request, timeout=DEFAULT_TIMEOUT)
            return f"삭제 완료: {command}"
    
    try:
        result = safe_grpc_call("Delete", grpc_operation)
        print(f"[CLIENT] 삭제 응답: {result}")
        return result
    except Exception as e:
        error_msg = f"삭제 실패: {str(e)}"
        print(f"[CLIENT] {error_msg}")
        return error_msg

def send_power_off_command(ip: str, port: int, command: str = "POWER_OFF") -> str:
    """전원 종료 명령 전송"""
    def grpc_operation():
        with create_channel_with_timeout(ip, port) as channel:
            stub = masterdevice_pb2_grpc.masterdeviceStub(channel)
            request = masterdevice_pb2.PowerOffStart(command=command)
            
            response = stub.PowerOff(request, timeout=DEFAULT_TIMEOUT)
            return response.message.strip()
    
    try:
        result = safe_grpc_call("PowerOff", grpc_operation)
        print(f"[CLIENT] PowerOff 응답: {result}")
        return result
    except Exception as e:
        error_msg = f"전원 종료 실패: {str(e)}"
        print(f"[CLIENT] {error_msg}")
        return error_msg

# ===============================
# 연결 테스트 함수
# ===============================

def test_connection(ip: str, port: int, timeout: float = 2.0) -> bool:
    """라즈베리파이 연결 테스트"""
    try:
        with create_channel_with_timeout(ip, port, timeout) as channel:
            # 간단한 연결 테스트 (타임아웃 짧게)
            stub = masterdevice_pb2_grpc.masterdeviceStub(channel)
            request = masterdevice_pb2.ConnectCommand(command="CONNECTION_TEST")
            
            response = stub.Connect(request, timeout=timeout)
            print(f"[CLIENT] 연결 테스트 성공: {ip}:{port}")
            return True
            
    except Exception as e:
        print(f"[CLIENT] 연결 테스트 실패 {ip}:{port}: {str(e)}")
        return False

def get_connection_status(ip: str, port: int) -> dict:
    """연결 상태 정보 반환"""
    start_time = time.time()
    is_connected = test_connection(ip, port, timeout=1.0)
    response_time = (time.time() - start_time) * 1000  # ms 단위
    
    return {
        "connected": is_connected,
        "ip": ip,
        "port": port,
        "response_time_ms": round(response_time, 2),
        "timestamp": time.strftime("%H:%M:%S")
    }

# ===============================
# 편의 함수들
# ===============================

def send_multiple_commands(ip: str, port: int, commands: list) -> list:
    """여러 명령을 순차적으로 전송"""
    results = []
    
    for cmd_info in commands:
        cmd_type = cmd_info.get("type")
        cmd_data = cmd_info.get("data")
        
        try:
            if cmd_type == "connect":
                result = send_connect_command(ip, port, cmd_data)
            elif cmd_type == "homing":
                result = send_homing_command(ip, port, cmd_data)
            elif cmd_type == "teleop":
                result = send_master_teleop_command(ip, port, cmd_data)
            elif cmd_type == "gravity":
                result = send_gravity_mode_command(ip, port, cmd_data)
            elif cmd_type == "position":
                result = send_position_mode_command(ip, port, cmd_data)
            else:
                result = f"알 수 없는 명령 타입: {cmd_type}"
            
            results.append({"type": cmd_type, "success": True, "result": result})
            
        except Exception as e:
            results.append({"type": cmd_type, "success": False, "error": str(e)})
    
    return results

def create_command_sequence() -> list:
    """일반적인 명령 시퀀스 생성 (예시)"""
    return [
        {"type": "connect", "data": "UI_CLIENT_CONNECT"},
        {"type": "homing", "data": "GO_HOME"},
        {"type": "gravity", "data": "GRAVITY_ON_ALL"},
        {"type": "teleop", "data": "START"}
    ]

# ===============================
# 메인 실행 부분 (테스트용)
# ===============================

if __name__ == "__main__":
    # 기본 테스트
    print("🔗 gRPC 클라이언트 테스트")
    print("=" * 50)
    
    # 기본 연결 정보
    test_ip = "192.168.0.43"
    test_port = 50051
    
    print(f"📍 테스트 대상: {test_ip}:{test_port}")
    
    # 연결 테스트
    print("\n1️⃣ 연결 테스트")
    status = get_connection_status(test_ip, test_port)
    print(f"   연결 상태: {'✅ 성공' if status['connected'] else '❌ 실패'}")
    print(f"   응답 시간: {status['response_time_ms']}ms")
    
    if status['connected']:
        print("\n2️⃣ 기본 명령 테스트")
        
        # Connect 테스트
        try:
            result = send_connect_command(test_ip, test_port, "TEST_CONNECTION")
            print(f"   Connect: ✅ {result}")
        except Exception as e:
            print(f"   Connect: ❌ {str(e)}")
        
        # Homing 테스트
        try:
            result = send_homing_command(test_ip, test_port, "GO_HOME")
            print(f"   Homing: ✅ {result}")
        except Exception as e:
            print(f"   Homing: ❌ {str(e)}")
        
        # Teleop 테스트
        try:
            result = send_master_teleop_command(test_ip, test_port, "START")
            print(f"   Teleop Start: ✅ {result}")
            
            result = send_master_teleop_command(test_ip, test_port, "STOP")
            print(f"   Teleop Stop: ✅ {result}")
        except Exception as e:
            print(f"   Teleop: ❌ {str(e)}")
    
    print("\n" + "=" * 50)
    print("🏁 테스트 완료")